export const inp = "w-full h-10 px-3 rounded-md bg-slate-950 border border-slate-800 text-slate-100 placeholder:text-slate-500 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none";
export const select = inp + " appearance-none";
export const lbl = "block text-xs font-semibold tracking-[0.2em] uppercase text-slate-400 mb-1.5";
export const card = "bg-slate-900 border border-slate-800 rounded-xl";
export const chip = "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-mono uppercase tracking-[0.1em] border";
export const btn = "inline-flex items-center gap-2 px-4 py-2 rounded-md text-sm";
export const btnPrimary = btn + " bg-indigo-600 hover:bg-indigo-500 text-white disabled:opacity-60 disabled:cursor-not-allowed";
export const btnGhost = btn + " border border-slate-800 hover:border-slate-700 text-slate-200";

export function badge(v) {
  const map = {
    "Critical": "bg-rose-500/10 border-rose-500/20 text-rose-300",
    "High": "bg-amber-500/10 border-amber-500/20 text-amber-300",
    "Medium": "bg-indigo-500/10 border-indigo-500/20 text-indigo-300",
    "Low": "bg-slate-700/40 border-slate-700 text-slate-300",
  };
  return `${chip} ${map[v] || "bg-slate-700/40 border-slate-700 text-slate-300"}`;
}
