import { useMemo, useState } from "react";
import { X, Search, Plus } from "lucide-react";
import { ALL_SKILLS, SKILL_CATEGORIES } from "@/lib/data";
import { inp, chip } from "@/components/hr/ui";

export default function SkillsPicker({ value = [], onChange, testId = "skills" }) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("All");
  const cats = ["All", ...Object.keys(SKILL_CATEGORIES)];

  const options = useMemo(() => {
    const s = q.trim().toLowerCase();
    return ALL_SKILLS.filter((x) => (cat === "All" || x.category === cat) && (!s || x.name.toLowerCase().includes(s)));
  }, [q, cat]);

  const toggle = (name) => {
    if (value.includes(name)) onChange(value.filter((v) => v !== name));
    else onChange([...value, name]);
  };

  const addCustom = () => {
    const t = q.trim();
    if (!t || value.includes(t)) return;
    onChange([...value, t]); setQ("");
  };

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-2 min-h-[24px]">
        {value.map((v) => (
          <span key={v} data-testid={`${testId}-chip-${v}`} className={`${chip} bg-indigo-500/10 border-indigo-500/20 text-indigo-200`}>
            {v}
            <button type="button" onClick={() => toggle(v)} className="ml-1 text-indigo-300 hover:text-white"><X className="w-3 h-3" /></button>
          </span>
        ))}
        {value.length === 0 && <span className="text-xs text-slate-500">None selected</span>}
      </div>
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input data-testid={`${testId}-search`} className={`${inp} pl-9`} placeholder="Search skills or type to add custom…" value={q} onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addCustom(); } }} />
        </div>
        <button type="button" onClick={addCustom} className="px-3 h-10 border border-slate-800 hover:border-slate-700 rounded-md text-sm inline-flex items-center gap-1"><Plus className="w-4 h-4" /> Add</button>
      </div>
      <div className="mt-2 flex flex-wrap gap-1">
        {cats.map((c) => (
          <button key={c} type="button" onClick={() => setCat(c)}
            className={`text-[11px] px-2 py-1 rounded-full border ${cat === c ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-200" : "border-slate-800 text-slate-400 hover:border-slate-700"}`}>
            {c}
          </button>
        ))}
      </div>
      <div className="mt-2 max-h-40 overflow-y-auto rounded-md border border-slate-800 bg-slate-950">
        {options.slice(0, 80).map((o) => {
          const on = value.includes(o.name);
          return (
            <button key={o.name} type="button" onClick={() => toggle(o.name)}
              className={`w-full text-left px-3 py-1.5 text-sm flex items-center justify-between ${on ? "bg-indigo-500/10 text-indigo-200" : "hover:bg-slate-800/60 text-slate-300"}`}>
              <span>{o.name}</span>
              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">{o.category}</span>
            </button>
          );
        })}
        {options.length === 0 && <p className="p-3 text-sm text-slate-500">No matches. Press Enter to add "{q}" as custom.</p>}
      </div>
    </div>
  );
}
