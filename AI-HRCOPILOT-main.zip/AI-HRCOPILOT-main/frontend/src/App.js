import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { Toaster } from "sonner";
import "@/App.css";

import Landing from "@/pages/Landing";
import Auth from "@/pages/Auth";
import DashboardLayout from "@/pages/DashboardLayout";
import Overview from "@/pages/Overview";
import Jobs from "@/pages/Jobs";
import JDGenerator from "@/pages/JDGenerator";
import Candidates from "@/pages/Candidates";
import ResumeAnalyzer from "@/pages/ResumeAnalyzer";
import InterviewAssistant from "@/pages/InterviewAssistant";
import CompetencyMapping from "@/pages/CompetencyMapping";
import SkillGapAnalyzer from "@/pages/SkillGapAnalyzer";
import CareerPath from "@/pages/CareerPath";
import Learning from "@/pages/Learning";
import CareerCoach from "@/pages/CareerCoach";
import Settings from "@/pages/Settings";
import ComingSoon from "@/pages/ComingSoon";

function Guard({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen grid place-items-center text-slate-400">Loading…</div>;
  if (!user) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster theme="dark" position="bottom-right" toastOptions={{ classNames: { toast: "bg-slate-900 border border-slate-800 text-slate-50" } }} />
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Auth mode="login" />} />
          <Route path="/signup" element={<Auth mode="signup" />} />
          <Route path="/dashboard" element={<Guard><DashboardLayout /></Guard>}>
            <Route index element={<Overview />} />
            <Route path="jobs" element={<Jobs />} />
            <Route path="jd-generator" element={<JDGenerator />} />
            <Route path="candidates" element={<Candidates />} />
            <Route path="resume-analyzer" element={<ResumeAnalyzer />} />
            <Route path="interview-assistant" element={<InterviewAssistant />} />
            <Route path="competency-mapping" element={<CompetencyMapping />} />
            <Route path="skill-gap-analyzer" element={<SkillGapAnalyzer />} />
            <Route path="career-path" element={<CareerPath />} />
            <Route path="learning" element={<Learning />} />
            <Route path="career-coach" element={<CareerCoach />} />} />
            <Route path="settings" element={<Settings />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
