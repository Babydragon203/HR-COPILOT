import { useEffect, useState } from "react";
import api, { formatError } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { INDUSTRIES, COMPANY_SIZES, ROLES } from "@/lib/data";
import { inp, select, lbl, card, btnPrimary, btnGhost, chip } from "@/components/hr/ui";
import { Users, Building2, Database, Plus, Trash2 } from "lucide-react";

export default function Settings() {
  const { user, refresh } = useAuth();
  const [org, setOrg] = useState(null);
  const [team, setTeam] = useState([]);
  const [busy, setBusy] = useState(false);
  const [showInvite, setShowInvite] = useState(false);
  const [invite, setInvite] = useState({ email: "", full_name: "", password: "", role: "recruiter" });

  const load = async () => {
    const [o, t] = await Promise.all([api.get("/org"), api.get("/org/team")]);
    setOrg(o.data); setTeam(t.data);
  };
  useEffect(() => { load(); }, []);

  const saveOrg = async () => {
    setBusy(true);
    try {
      await api.patch("/org", { name: org.name, industry: org.industry, company_size: org.company_size });
      toast.success("Organization updated.");
      await refresh();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const seedDemo = async () => {
    setBusy(true);
    try {
      const { data } = await api.post("/demo/seed");
      toast.success(data.already_loaded ? "Demo data already loaded." : `Seeded ${data.jobs} demo jobs and ${data.candidates} candidates.`);
      load();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const clearDemo = async () => {
    setBusy(true);
    try { await api.delete("/demo/clear"); toast.success("Demo data cleared."); load(); }
    catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const addMember = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post("/org/team", invite);
      toast.success("Team member added.");
      setInvite({ email: "", full_name: "", password: "", role: "recruiter" });
      setShowInvite(false); load();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  if (!org) return <p className="text-slate-400">Loading…</p>;
  const isAdmin = user?.role === "org_admin";

  return (
    <div className="space-y-8 max-w-5xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Settings</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Organization</h1>
      </div>

      <div className={`${card} p-6 space-y-4`}>
        <div className="flex items-center gap-2 text-indigo-300"><Building2 className="w-4 h-4" strokeWidth={1.5} /><h2 className="font-display text-lg text-slate-100">Company profile</h2></div>
        <div className="grid md:grid-cols-3 gap-3">
          <Field label="Name"><input data-testid="org-name" className={inp} value={org.name || ""} onChange={(e) => setOrg({ ...org, name: e.target.value })} disabled={!isAdmin} /></Field>
          <Field label="Industry"><select data-testid="org-industry" className={select} value={org.industry || "Technology"} onChange={(e) => setOrg({ ...org, industry: e.target.value })} disabled={!isAdmin}>{INDUSTRIES.map((i) => <option key={i} className="bg-slate-900">{i}</option>)}</select></Field>
          <Field label="Company size"><select data-testid="org-size" className={select} value={org.company_size || "Startup"} onChange={(e) => setOrg({ ...org, company_size: e.target.value })} disabled={!isAdmin}>{COMPANY_SIZES.map((i) => <option key={i} className="bg-slate-900">{i}</option>)}</select></Field>
        </div>
        {isAdmin && <button data-testid="org-save" onClick={saveOrg} disabled={busy} className={btnPrimary}>Save changes</button>}
      </div>

      <div className={`${card} p-6 space-y-4`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-indigo-300"><Users className="w-4 h-4" strokeWidth={1.5} /><h2 className="font-display text-lg text-slate-100">Team & Roles</h2></div>
          {isAdmin && <button data-testid="invite-btn" onClick={() => setShowInvite(!showInvite)} className={btnGhost}><Plus className="w-4 h-4" /> Add Member</button>}
        </div>

        {showInvite && isAdmin && (
          <form onSubmit={addMember} className="p-4 rounded-lg bg-slate-950 border border-slate-800 grid md:grid-cols-4 gap-3">
            <Field label="Full name"><input required data-testid="invite-name" className={inp} value={invite.full_name} onChange={(e) => setInvite({ ...invite, full_name: e.target.value })} /></Field>
            <Field label="Email"><input required type="email" data-testid="invite-email" className={inp} value={invite.email} onChange={(e) => setInvite({ ...invite, email: e.target.value })} /></Field>
            <Field label="Password"><input required minLength={8} type="password" data-testid="invite-password" className={inp} value={invite.password} onChange={(e) => setInvite({ ...invite, password: e.target.value })} /></Field>
            <Field label="Role"><select data-testid="invite-role" className={select} value={invite.role} onChange={(e) => setInvite({ ...invite, role: e.target.value })}>{ROLES.map((r) => <option key={r.key} value={r.key} className="bg-slate-900">{r.label}</option>)}</select></Field>
            <div className="md:col-span-4"><button data-testid="invite-submit" disabled={busy} className={btnPrimary}>Add member</button></div>
          </form>
        )}

        <div className="overflow-hidden rounded-lg border border-slate-800">
          <table className="w-full text-sm">
            <thead className="bg-slate-900 border-b border-slate-800">
              <tr className="text-left text-xs font-mono uppercase tracking-[0.15em] text-slate-500">
                <th className="px-4 py-3">Name</th><th className="px-4 py-3">Email</th><th className="px-4 py-3">Role</th>
              </tr>
            </thead>
            <tbody>
              {team.map((m) => (
                <tr key={m.id} className="border-b border-slate-800">
                  <td className="px-4 py-3 text-slate-100">{m.full_name}</td>
                  <td className="px-4 py-3 text-slate-400">{m.email}</td>
                  <td className="px-4 py-3"><span className={`${chip} border-indigo-500/20 text-indigo-300`}>{m.role.replace("_", " ")}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className={`${card} p-6 space-y-4`}>
        <div className="flex items-center gap-2 text-cyan-300"><Database className="w-4 h-4" strokeWidth={1.5} /><h2 className="font-display text-lg text-slate-100">Demo Data</h2></div>
        <p className="text-sm text-slate-400">Populate your workspace with clearly-labeled DEMO DATA to explore the platform. You can clear it any time.</p>
        {org.demo_data_loaded ? (
          <div className="flex items-center gap-2">
            <span className={`${chip} border-cyan-400/20 text-cyan-300`}>DEMO DATA loaded</span>
            {isAdmin && <button data-testid="demo-clear" onClick={clearDemo} disabled={busy} className={btnGhost}><Trash2 className="w-4 h-4" /> Clear demo data</button>}
          </div>
        ) : (
          isAdmin && <button data-testid="demo-seed" onClick={seedDemo} disabled={busy} className={btnPrimary}>Seed demo data</button>
        )}
      </div>
    </div>
  );
}

const Field = ({ label, children }) => (<label className="block"><span className={lbl}>{label}</span>{children}</label>);
