import { Link } from "react-router-dom";
import { Sparkles, FileText, Users, MessageSquare, ArrowRight, ShieldCheck, Cpu, Zap } from "lucide-react";

const MODULES = [
  { icon: FileText, title: "JD Generator", desc: "Draft polished, inclusive job descriptions in seconds with configurable style, length, and section control." },
  { icon: Users, title: "Resume Analyzer", desc: "Structured candidate extraction and weighted job-fit analysis with transparent scoring." },
  { icon: MessageSquare, title: "Interview Assistant", desc: "Role-specific interview kits, scoring rubrics, and evaluation-ready scorecards." },
];

const SOON = ["Competency Mapping", "Skill Gap Analyzer", "Learning Recommendations"];

export default function Landing() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="sticky top-0 z-40 border-b border-white/5 bg-slate-950/70 backdrop-blur-2xl">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-indigo-500/20 border border-indigo-500/30 grid place-items-center"><Sparkles className="w-4 h-4 text-indigo-300" strokeWidth={1.5} /></div>
            <span className="font-display text-lg font-semibold tracking-tight">HR Copilot AI</span>
          </div>
          <nav className="flex items-center gap-3">
            <Link to="/login" data-testid="nav-login" className="text-sm text-slate-300 hover:text-white px-3 py-2">Log in</Link>
            <Link to="/signup" data-testid="nav-signup" className="text-sm bg-indigo-600 hover:bg-indigo-500 px-4 py-2 rounded-md font-medium">Get started</Link>
          </nav>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle_at_20%_10%,rgba(99,102,241,0.15),transparent_45%),radial-gradient(circle_at_80%_30%,rgba(34,211,238,0.1),transparent_40%)]" />
        <div className="relative max-w-7xl mx-auto px-6 py-24 lg:py-32">
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 rounded-full px-3 py-1">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" /> Recruitment · V1
            </span>
            <h1 className="mt-6 font-display text-4xl sm:text-5xl lg:text-6xl font-light leading-[1.05]">
              AI-powered HR workflows,<br /><span className="text-indigo-300 font-semibold">from hiring to talent development.</span>
            </h1>
            <p className="mt-6 text-lg text-slate-300 max-w-2xl leading-relaxed">
              A production-grade B2B platform for modern HR teams — draft job descriptions, analyze resumes against roles, and run structured interviews, all under one enterprise workspace.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Link to="/signup" data-testid="hero-cta-signup" className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-md font-medium">
                Start free <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to="/login" data-testid="hero-cta-login" className="inline-flex items-center gap-2 border border-slate-800 hover:border-slate-700 px-6 py-3 rounded-md text-slate-100">
                Log in
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-20 border-t border-white/5">
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-400">The V1 modules</p>
        <h2 className="mt-3 font-display text-3xl sm:text-4xl font-semibold">Recruitment, end to end.</h2>
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          {MODULES.map((m) => (
            <div key={m.title} data-testid={`module-card-${m.title}`} className="bg-slate-900 border border-slate-800 rounded-xl p-6 hover:border-slate-700 transition-colors">
              <div className="w-10 h-10 rounded-lg bg-indigo-500/10 border border-indigo-500/20 grid place-items-center mb-4"><m.icon className="w-5 h-5 text-indigo-300" strokeWidth={1.5} /></div>
              <h3 className="font-display text-xl font-medium">{m.title}</h3>
              <p className="mt-2 text-sm text-slate-400 leading-relaxed">{m.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-16">
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-400">Coming Soon · Talent Development</p>
          <div className="mt-4 flex flex-wrap gap-2">
            {SOON.map((s) => (
              <span key={s} className="inline-flex items-center gap-2 text-sm text-slate-300 bg-slate-900 border border-dashed border-slate-800 rounded-full px-4 py-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" /> {s}
              </span>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-20 border-t border-white/5 grid md:grid-cols-3 gap-6">
        {[
          { icon: ShieldCheck, title: "Multi-tenant, isolated by design", body: "Each organization's jobs, candidates, and resumes are scoped and access-controlled at the API layer." },
          { icon: Cpu, title: "Powered by Claude Sonnet 5", body: "Structured, reviewable AI output. Recommendations are advisory — humans make the final call." },
          { icon: Zap, title: "Built for HR velocity", body: "From requisition to interview kit in minutes, without the boilerplate." },
        ].map((f) => (
          <div key={f.title} className="p-6 bg-slate-900/50 border border-slate-800 rounded-xl">
            <f.icon className="w-5 h-5 text-cyan-300" strokeWidth={1.5} />
            <h4 className="mt-3 font-display text-lg font-medium">{f.title}</h4>
            <p className="mt-2 text-sm text-slate-400 leading-relaxed">{f.body}</p>
          </div>
        ))}
      </section>

      <footer className="border-t border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-6 text-sm text-slate-500 flex flex-wrap gap-4 justify-between">
          <span>© {new Date().getFullYear()} HR Copilot AI</span>
          <span>AI outputs are advisory. Always review before making HR decisions.</span>
        </div>
      </footer>
    </div>
  );
}
