import { useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Sparkles, Save, Wand2, Loader2 } from "lucide-react";
import {
  INDUSTRIES, COMPANY_SIZES, DEPARTMENTS, JOB_TITLES, SENIORITIES, EXPERIENCE_RANGES,
  EMPLOYMENT_TYPES, WORK_ARRANGEMENTS, CURRENCIES, PRIORITIES, TIMELINES,
  BENEFITS, CERTIFICATIONS, LANGUAGES, JD_STYLES, JD_LENGTHS, JD_SECTIONS,
} from "@/lib/data";
import SkillsPicker from "@/components/hr/SkillsPicker";
import { inp, select, lbl, card, btnPrimary, btnGhost } from "@/components/hr/ui";

const REFINE_ACTIONS = ["improve", "expand", "shorten", "professional", "concise"];

export default function JDGenerator() {
  const [form, setForm] = useState({
    company_name: "", industry: "Technology", company_size: "Startup",
    department: "", title: "", seniority: "Mid Level", experience: "3-5 years",
    employment_type: "Full-time", work_arrangement: "Hybrid", location: "",
    salary_currency: "USD", salary_min: "", salary_max: "",
    priority: "Medium", timeline: "Within 30 Days",
    required_skills: [], preferred_skills: [], certifications: [], languages: [], benefits: [],
    style: "Professional", length: "Standard",
    include_sections: [...JD_SECTIONS],
  });
  const [content, setContent] = useState(null);
  const [input, setInput] = useState(null);
  const [gen, setGen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [refining, setRefining] = useState(null);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const toggleSection = (s) => set("include_sections", form.include_sections.includes(s) ? form.include_sections.filter((x) => x !== s) : [...form.include_sections, s]);
  const toggleBenefit = (s) => set("benefits", form.benefits.includes(s) ? form.benefits.filter((x) => x !== s) : [...form.benefits, s]);

  const generate = async () => {
    if (!form.company_name || !form.department || !form.title) {
      toast.error("Company name, department and title are required.");
      return;
    }
    if (form.salary_min && form.salary_max && Number(form.salary_min) > Number(form.salary_max)) {
      toast.error("Min salary cannot exceed max salary."); return;
    }
    setGen(true);
    try {
      const payload = { ...form,
        salary_min: form.salary_min ? Number(form.salary_min) : null,
        salary_max: form.salary_max ? Number(form.salary_max) : null };
      const { data } = await api.post("/jd/generate", payload);
      setContent(data.content); setInput(data.input);
      toast.success("Job description generated.");
    } catch (err) { toast.error(formatError(err)); }
    finally { setGen(false); }
  };

  const save = async (status = "draft") => {
    if (!content) return;
    setSaving(true);
    try {
      await api.post("/jd", { title: content.job_title || form.title, input, content, status });
      toast.success(`JD saved as ${status}.`);
    } catch (err) { toast.error(formatError(err)); }
    finally { setSaving(false); }
  };

  const refine = async (section, action) => {
    setRefining(`${section}-${action}`);
    try {
      const key = section;
      const current = Array.isArray(content[key]) ? content[key].join("\n• ") : (content[key] || "");
      const { data } = await api.post("/jd/refine", { section: key, current_text: String(current), action });
      setContent((c) => ({ ...c, [key]: Array.isArray(c[key]) ? data.text.split(/\n[•\-]?\s*/).filter(Boolean) : data.text }));
      toast.success("Refined.");
    } catch (err) { toast.error(formatError(err)); }
    finally { setRefining(null); }
  };

  const updateField = (k, v) => setContent((c) => ({ ...c, [k]: v }));

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Recruitment</p>
          <h1 className="mt-2 font-display text-3xl font-semibold">JD Generator</h1>
          <p className="mt-1 text-sm text-slate-400">Draft polished job descriptions with control over style, length, and included sections.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        <div className={`${card} p-6 lg:col-span-2 space-y-4 max-h-[85vh] overflow-y-auto`}>
          <h2 className="font-display text-lg">Role brief</h2>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Company"><input data-testid="jd-company" className={inp} value={form.company_name} onChange={(e) => set("company_name", e.target.value)} /></Field>
            <Field label="Industry"><select className={select} value={form.industry} onChange={(e) => set("industry", e.target.value)}>{INDUSTRIES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Company size"><select className={select} value={form.company_size} onChange={(e) => set("company_size", e.target.value)}>{COMPANY_SIZES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Department"><select data-testid="jd-department" className={select} value={form.department} onChange={(e) => set("department", e.target.value)}><option value="">Select…</option>{DEPARTMENTS.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Job title"><input data-testid="jd-title" list="jd-titles" className={inp} value={form.title} onChange={(e) => set("title", e.target.value)} /><datalist id="jd-titles">{JOB_TITLES.map((t) => <option key={t} value={t} />)}</datalist></Field>
            <Field label="Seniority"><select className={select} value={form.seniority} onChange={(e) => set("seniority", e.target.value)}>{SENIORITIES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Experience"><select className={select} value={form.experience} onChange={(e) => set("experience", e.target.value)}>{EXPERIENCE_RANGES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Employment"><select className={select} value={form.employment_type} onChange={(e) => set("employment_type", e.target.value)}>{EMPLOYMENT_TYPES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Arrangement"><select className={select} value={form.work_arrangement} onChange={(e) => set("work_arrangement", e.target.value)}>{WORK_ARRANGEMENTS.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Location"><input className={inp} value={form.location} onChange={(e) => set("location", e.target.value)} /></Field>
            <Field label="Currency"><select className={select} value={form.salary_currency} onChange={(e) => set("salary_currency", e.target.value)}>{CURRENCIES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Priority"><select className={select} value={form.priority} onChange={(e) => set("priority", e.target.value)}>{PRIORITIES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Salary min"><input type="number" className={inp} value={form.salary_min} onChange={(e) => set("salary_min", e.target.value)} /></Field>
            <Field label="Salary max"><input type="number" className={inp} value={form.salary_max} onChange={(e) => set("salary_max", e.target.value)} /></Field>
            <Field label="Timeline"><select className={select} value={form.timeline} onChange={(e) => set("timeline", e.target.value)}>{TIMELINES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Style"><select className={select} value={form.style} onChange={(e) => set("style", e.target.value)}>{JD_STYLES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Length"><select className={select} value={form.length} onChange={(e) => set("length", e.target.value)}>{JD_LENGTHS.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
          </div>

          <Field label="Required skills"><SkillsPicker value={form.required_skills} onChange={(v) => set("required_skills", v)} testId="jd-req-skills" /></Field>
          <Field label="Preferred skills"><SkillsPicker value={form.preferred_skills} onChange={(v) => set("preferred_skills", v)} testId="jd-pref-skills" /></Field>

          <Field label="Benefits">
            <div className="flex flex-wrap gap-1.5">
              {BENEFITS.map((b) => {
                const on = form.benefits.includes(b);
                return <button key={b} type="button" onClick={() => toggleBenefit(b)} className={`text-xs px-2.5 py-1 rounded-full border ${on ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-200" : "border-slate-800 text-slate-400 hover:border-slate-700"}`}>{b}</button>;
              })}
            </div>
          </Field>

          <Field label="Include sections">
            <div className="flex flex-wrap gap-1.5">
              {JD_SECTIONS.map((s) => {
                const on = form.include_sections.includes(s);
                return <button key={s} type="button" onClick={() => toggleSection(s)} data-testid={`jd-section-${s}`} className={`text-xs px-2.5 py-1 rounded-full border ${on ? "bg-cyan-500/10 border-cyan-500/30 text-cyan-200" : "border-slate-800 text-slate-400"}`}>{s}</button>;
              })}
            </div>
          </Field>

          <button data-testid="jd-generate-btn" onClick={generate} disabled={gen} className={btnPrimary + " w-full justify-center"}>
            {gen ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating…</> : <><Sparkles className="w-4 h-4" /> Generate Job Description</>}
          </button>
        </div>

        <div className={`${card} p-6 lg:col-span-3 space-y-4 max-h-[85vh] overflow-y-auto`}>
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg">Generated JD</h2>
            {content && (
              <div className="flex gap-2">
                <button data-testid="jd-save-draft" onClick={() => save("draft")} disabled={saving} className={btnGhost}><Save className="w-4 h-4" /> Save Draft</button>
                <button data-testid="jd-publish" onClick={() => save("published")} disabled={saving} className={btnPrimary}><Save className="w-4 h-4" /> Publish</button>
              </div>
            )}
          </div>

          {!content && !gen && (
            <div className="p-8 border border-dashed border-slate-800 rounded-lg text-center text-slate-500">
              <Sparkles className="w-6 h-6 mx-auto text-slate-600" />
              <p className="mt-2 text-sm">Fill the role brief and click Generate.</p>
            </div>
          )}

          {content && (
            <div className="space-y-4">
              <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-amber-400 bg-amber-500/5 border border-amber-500/20 rounded-md px-3 py-2">
                AI-generated content. Review before making HR decisions.
              </div>
              {[
                ["job_title", "Job Title", "input"],
                ["company_overview", "Company Overview", "textarea"],
                ["job_summary", "Job Summary", "textarea"],
                ["responsibilities", "Responsibilities", "list"],
                ["required_skills", "Required Skills", "list"],
                ["preferred_skills", "Preferred Skills", "list"],
                ["qualifications", "Qualifications", "list"],
                ["experience", "Experience", "textarea"],
                ["reporting_structure", "Reporting Structure", "textarea"],
                ["kpis", "KPIs", "list"],
                ["benefits", "Benefits", "list"],
                ["career_growth", "Career Growth", "textarea"],
                ["diversity_statement", "Diversity Statement", "textarea"],
              ].map(([key, label, kind]) => (
                <Section key={key} label={label} field={key} kind={kind} value={content[key]} onChange={updateField} onRefine={refine} refining={refining} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Section({ label, field, kind, value, onChange, onRefine, refining }) {
  const listVal = Array.isArray(value) ? value.join("\n") : "";
  return (
    <div className="border border-slate-800 rounded-lg p-4">
      <div className="flex items-center justify-between mb-2">
        <p className={lbl}>{label}</p>
        <div className="flex gap-1">
          {REFINE_ACTIONS.map((a) => (
            <button key={a} onClick={() => onRefine(field, a)} disabled={!!refining}
              data-testid={`jd-refine-${field}-${a}`}
              className="text-[10px] px-2 py-0.5 rounded border border-slate-800 hover:border-indigo-500/30 hover:text-indigo-200 text-slate-400 disabled:opacity-40">
              {refining === `${field}-${a}` ? <Loader2 className="w-3 h-3 animate-spin inline" /> : <><Wand2 className="w-3 h-3 inline mr-1" />{a}</>}
            </button>
          ))}
        </div>
      </div>
      {kind === "input" && <input className={inp} value={value || ""} onChange={(e) => onChange(field, e.target.value)} />}
      {kind === "textarea" && <textarea rows={3} className={`${inp} h-auto py-2 resize-y`} value={value || ""} onChange={(e) => onChange(field, e.target.value)} />}
      {kind === "list" && (
        <textarea rows={4} className={`${inp} h-auto py-2 resize-y`} value={listVal}
          onChange={(e) => onChange(field, e.target.value.split("\n").map((s) => s.replace(/^[•\-\*]\s*/, "")).filter(Boolean))}
          placeholder="One item per line" />
      )}
    </div>
  );
}

const Field = ({ label, children }) => (<label className="block"><span className={lbl}>{label}</span>{children}</label>);
