import { useEffect, useRef, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Upload, ScanText, Loader2, FileText } from "lucide-react";
import { inp, lbl, card, btnPrimary, select } from "@/components/hr/ui";

export default function ResumeAnalyzer() {
  const [jobs, setJobs] = useState([]);
  const [jobId, setJobId] = useState("");
  const [file, setFile] = useState(null);
  const [resume, setResume] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [weights, setWeights] = useState({ skills: 40, experience: 30, qualifications: 20, other: 10 });
  const [busy, setBusy] = useState(false);
  const [drag, setDrag] = useState(false);
  const inputRef = useRef(null);

  useEffect(() => { api.get("/jobs").then((r) => setJobs(r.data)); }, []);

  const total = weights.skills + weights.experience + weights.qualifications + weights.other;

  const onFile = (f) => {
    if (!f) return;
    const ext = f.name.split(".").pop()?.toLowerCase();
    if (!["pdf", "docx", "txt"].includes(ext)) { toast.error("Unsupported file type. Use PDF, DOCX, or TXT."); return; }
    if (f.size > 10 * 1024 * 1024) { toast.error("File exceeds 10MB."); return; }
    setFile(f);
  };

  const upload = async () => {
    if (!file) return;
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      if (jobId) fd.append("job_id", jobId);
      const { data } = await api.post("/resumes/upload", fd, { headers: { "Content-Type": "multipart/form-data" } });
      setResume(data);
      toast.success("Resume uploaded.");
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const analyze = async () => {
    if (!resume || !jobId) { toast.error("Upload a resume and select a job."); return; }
    if (total !== 100) { toast.error("Weights must sum to 100."); return; }
    setBusy(true);
    try {
      const { data } = await api.post("/resumes/analyze", { resume_id: resume.id, job_id: jobId, weights });
      setAnalysis(data);
      toast.success("Analysis complete. Candidate added to pipeline.");
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-6 max-w-6xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Recruitment</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Resume Analyzer</h1>
        <p className="mt-1 text-sm text-slate-400">Upload a resume and score it against a job with configurable weighting.</p>
      </div>

      <div className={`${card} p-6 space-y-4`}>
        <label className={lbl}>Select Job</label>
        <select data-testid="ra-job" className={select} value={jobId} onChange={(e) => setJobId(e.target.value)}>
          <option value="" className="bg-slate-900">Choose a job…</option>
          {jobs.map((j) => <option key={j.id} value={j.id} className="bg-slate-900">{j.title} · {j.department}</option>)}
        </select>

        <div
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); onFile(e.dataTransfer.files?.[0]); }}
          className={`border-2 border-dashed rounded-lg p-8 text-center bg-slate-900/50 ${drag ? "border-indigo-500" : "border-slate-700"}`}
        >
          <Upload className="w-6 h-6 text-slate-500 mx-auto" />
          <p className="mt-3 text-sm text-slate-300">{file ? file.name : "Drag & drop a resume, or"}</p>
          <button type="button" data-testid="ra-browse" onClick={() => inputRef.current?.click()} className="mt-2 text-indigo-300 hover:text-indigo-200 text-sm">Browse files</button>
          <input ref={inputRef} type="file" accept=".pdf,.docx,.txt" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
          <p className="mt-2 text-xs text-slate-500">PDF, DOCX or TXT · Max 10 MB</p>
        </div>

        <div className="flex gap-2">
          <button data-testid="ra-upload" onClick={upload} disabled={!file || busy} className={btnPrimary}>{busy && !resume ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />} Upload</button>
          {resume && <span className="text-xs text-slate-500 self-center font-mono">{resume.original_filename} · {(resume.size/1024).toFixed(1)} KB</span>}
        </div>
      </div>

      <div className={`${card} p-6 space-y-4`}>
        <h2 className="font-display text-lg">Scoring weights</h2>
        <p className="text-xs text-slate-500">Total must equal 100. Current: <span className={`font-mono ${total === 100 ? "text-emerald-300" : "text-rose-300"}`}>{total}</span></p>
        {["skills", "experience", "qualifications", "other"].map((k) => (
          <div key={k} className="flex items-center gap-3">
            <span className="w-32 text-sm text-slate-300 capitalize">{k}</span>
            <input type="range" min="0" max="100" value={weights[k]} onChange={(e) => setWeights({ ...weights, [k]: Number(e.target.value) })}
              data-testid={`ra-w-${k}`} className="flex-1 accent-indigo-500" />
            <span className="w-10 text-right font-mono text-indigo-300">{weights[k]}</span>
          </div>
        ))}
        <button data-testid="ra-analyze" onClick={analyze} disabled={busy || !resume || !jobId || total !== 100} className={btnPrimary}>
          {busy && resume ? <Loader2 className="w-4 h-4 animate-spin" /> : <ScanText className="w-4 h-4" />} Analyze
        </button>
      </div>

      {analysis && (
        <div className={`${card} p-6 space-y-4`}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Candidate</p>
              <h2 className="font-display text-xl">{analysis.name}</h2>
              <p className="text-sm text-slate-400">{analysis.email || "Email not detected"}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Internal Job Match</p>
              <p className="font-display text-4xl text-indigo-300">{analysis.analysis?.overall_score}</p>
              <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-amber-400/80 max-w-[220px]">Heuristic. Not a hiring decision.</p>
            </div>
          </div>
          <p className="text-sm text-slate-300">{analysis.analysis?.summary}</p>
          <div className="grid md:grid-cols-2 gap-4 text-sm">
            <Panel title="Matched skills" items={analysis.analysis?.matched_skills} tone="text-emerald-300" />
            <Panel title="Missing skills" items={analysis.analysis?.missing_skills} tone="text-rose-300" />
            <Panel title="Strengths" items={analysis.analysis?.strengths} tone="text-slate-200" />
            <Panel title="Gaps" items={analysis.analysis?.gaps} tone="text-slate-200" />
          </div>
        </div>
      )}
    </div>
  );
}

const Panel = ({ title, items, tone }) => (
  <div className="p-4 rounded-lg bg-slate-950 border border-slate-800">
    <p className={lbl}>{title}</p>
    <ul className={`list-disc list-inside space-y-1 ${tone}`}>{(items || []).map((i, idx) => <li key={idx}>{i}</li>)}{(!items || items.length === 0) && <li className="list-none text-slate-600">—</li>}</ul>
  </div>
);
