import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { Sparkles } from "lucide-react";
import { INDUSTRIES, COMPANY_SIZES } from "@/lib/data";

export default function Auth({ mode = "login" }) {
  const isSignup = mode === "signup";
  const nav = useNavigate();
  const { login, signup, formatError } = useAuth();
  const [form, setForm] = useState({
    email: "", password: "", full_name: "",
    organization_name: "", industry: "Technology", company_size: "Startup",
  });
  const [submitting, setSubmitting] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const onSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (isSignup) {
        await signup(form);
        toast.success("Welcome! Your organization is ready.");
      } else {
        await login(form.email, form.password);
        toast.success("Signed in.");
      }
      nav("/dashboard");
    } catch (err) {
      toast.error(formatError(err));
    } finally { setSubmitting(false); }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 grid lg:grid-cols-2">
      <div className="hidden lg:flex flex-col justify-between p-12 border-r border-slate-800 bg-slate-950">
        <Link to="/" className="flex items-center gap-2 w-fit">
          <div className="w-8 h-8 rounded-md bg-indigo-500/20 border border-indigo-500/30 grid place-items-center"><Sparkles className="w-4 h-4 text-indigo-300" strokeWidth={1.5} /></div>
          <span className="font-display text-lg font-semibold">HR Copilot AI</span>
        </Link>
        <div>
          <h2 className="font-display text-4xl font-light leading-tight">A single workspace for<br /><span className="text-indigo-300 font-semibold">everything hiring.</span></h2>
          <p className="mt-4 text-slate-400 max-w-md">JD Generator · Resume Analyzer · Interview Assistant. Built for HR teams that ship.</p>
        </div>
        <p className="text-xs text-slate-500 font-mono uppercase tracking-[0.2em]">V1 · Recruitment</p>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-12">
        <form onSubmit={onSubmit} className="w-full max-w-md space-y-5" data-testid={`${mode}-form`}>
          <div>
            <h1 className="font-display text-3xl font-semibold">{isSignup ? "Create your organization" : "Welcome back"}</h1>
            <p className="mt-1 text-sm text-slate-400">{isSignup ? "You'll be the Organization Admin." : "Sign in to your HR workspace."}</p>
          </div>

          {isSignup && (
            <>
              <Field label="Full name">
                <input required data-testid="signup-full-name" className={inp} value={form.full_name} onChange={(e) => set("full_name", e.target.value)} placeholder="Jane Doe" />
              </Field>
              <Field label="Organization name">
                <input required data-testid="signup-org-name" className={inp} value={form.organization_name} onChange={(e) => set("organization_name", e.target.value)} placeholder="Acme HR" />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Industry">
                  <select data-testid="signup-industry" className={inp} value={form.industry} onChange={(e) => set("industry", e.target.value)}>
                    {INDUSTRIES.map((i) => <option key={i} value={i} className="bg-slate-900">{i}</option>)}
                  </select>
                </Field>
                <Field label="Company size">
                  <select data-testid="signup-company-size" className={inp} value={form.company_size} onChange={(e) => set("company_size", e.target.value)}>
                    {COMPANY_SIZES.map((s) => <option key={s} value={s} className="bg-slate-900">{s}</option>)}
                  </select>
                </Field>
              </div>
            </>
          )}

          <Field label="Work email">
            <input required type="email" data-testid={`${mode}-email`} className={inp} value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@company.com" />
          </Field>
          <Field label="Password">
            <input required minLength={8} type="password" data-testid={`${mode}-password`} className={inp} value={form.password} onChange={(e) => set("password", e.target.value)} placeholder={isSignup ? "Min. 8 characters" : ""} />
          </Field>

          <button type="submit" disabled={submitting} data-testid={`${mode}-submit`}
            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 disabled:cursor-not-allowed py-2.5 rounded-md font-medium">
            {submitting ? "Please wait…" : (isSignup ? "Create organization" : "Sign in")}
          </button>

          <p className="text-sm text-slate-400 text-center">
            {isSignup ? (
              <>Already have an account? <Link to="/login" className="text-indigo-300 hover:text-indigo-200">Sign in</Link></>
            ) : (
              <>New here? <Link to="/signup" className="text-indigo-300 hover:text-indigo-200">Create an organization</Link></>
            )}
          </p>
        </form>
      </div>
    </div>
  );
}

const inp = "w-full h-10 px-3 rounded-md bg-slate-900 border border-slate-800 text-slate-100 placeholder:text-slate-500 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none";

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="block text-xs font-semibold tracking-[0.2em] uppercase text-slate-400 mb-1.5">{label}</span>
      {children}
    </label>
  );
}
