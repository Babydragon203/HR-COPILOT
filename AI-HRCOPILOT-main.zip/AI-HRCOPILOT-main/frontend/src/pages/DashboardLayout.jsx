import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import {
  LayoutDashboard, Briefcase, FileText, Users, ScanText, MessageSquare,
  Target, TrendingUp, GraduationCap, Bot, Route as RouteIcon, Settings as SettingsIcon, Sparkles, LogOut,
} from "lucide-react";
import { toast } from "sonner";

const RECRUITMENT = [
  { to: "/dashboard", label: "Overview", icon: LayoutDashboard, end: true },
  { to: "/dashboard/jobs", label: "Jobs", icon: Briefcase },
  { to: "/dashboard/jd-generator", label: "JD Generator", icon: FileText },
  { to: "/dashboard/candidates", label: "Candidates", icon: Users },
  { to: "/dashboard/resume-analyzer", label: "Resume Analyzer", icon: ScanText },
  { to: "/dashboard/interview-assistant", label: "Interview Assistant", icon: MessageSquare },
];

const TALENT = [
  { to: "/dashboard/competency-mapping", label: "Competency Mapping", icon: Target },
  { to: "/dashboard/skill-gap-analyzer", label: "Skill Gap Analyzer", icon: TrendingUp },
  { to: "/dashboard/career-path", label: "Career Path", icon: RouteIcon },
  { to: "/dashboard/learning", label: "Learning Recs", icon: GraduationCap },
  { to: "/dashboard/career-coach", label: "Career Coach", icon: Bot },
];

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const nav = useNavigate();

  const onLogout = async () => {
    await logout();
    toast.success("Signed out.");
    nav("/login");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex">
      <aside className="w-64 shrink-0 border-r border-slate-800 bg-slate-950 sticky top-0 h-screen overflow-y-auto">
        <Link to="/" className="flex items-center gap-2 px-5 h-16 border-b border-slate-800">
          <div className="w-8 h-8 rounded-md bg-indigo-500/20 border border-indigo-500/30 grid place-items-center"><Sparkles className="w-4 h-4 text-indigo-300" strokeWidth={1.5} /></div>
          <span className="font-display text-base font-semibold">HR Copilot AI</span>
        </Link>

        <div className="p-4 space-y-6">
          <NavGroup title="Recruitment" items={RECRUITMENT} />
          <NavGroup title="Talent Development" items={TALENT} />
          <div>
            <p className="px-2 mb-2 text-[10px] font-mono uppercase tracking-[0.2em] text-slate-500">Settings</p>
            <SideLink to="/dashboard/settings" label="Organization & Team" icon={SettingsIcon} />
          </div>
        </div>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 border-b border-slate-800 bg-slate-950/70 backdrop-blur-2xl flex items-center justify-between px-6 sticky top-0 z-30">
          <div>
            <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">{user?.organization?.name || "Organization"}</p>
            <p className="text-sm text-slate-200">{user?.full_name}</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono uppercase tracking-[0.15em] px-2 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300">
              {user?.role?.replace("_", " ")}
            </span>
            <button data-testid="logout-btn" onClick={onLogout} className="inline-flex items-center gap-2 text-sm text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 rounded-md px-3 py-1.5">
              <LogOut className="w-4 h-4" strokeWidth={1.5} /> Log out
            </button>
          </div>
        </header>
        <main className="flex-1 p-6 lg:p-8"><Outlet /></main>
      </div>
    </div>
  );
}

function NavGroup({ title, items, comingSoon }) {
  return (
    <div>
      <p className="px-2 mb-2 text-[10px] font-mono uppercase tracking-[0.2em] text-slate-500 flex items-center gap-2">
        {title}
        {comingSoon && <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-400/10 border border-cyan-400/20 text-cyan-300">Preview</span>}
      </p>
      <div className="space-y-0.5">
        {items.map((i) => <SideLink key={i.to} {...i} />)}
      </div>
    </div>
  );
}

function SideLink({ to, label, icon: Icon, end }) {
  return (
    <NavLink to={to} end={end} title={label} data-testid={`nav-${label.toLowerCase().replace(/\s+/g, "-")}`}
      className={({ isActive }) =>
        `flex items-center gap-2.5 px-2.5 py-2 rounded-md text-sm ${isActive ? "bg-indigo-500/10 text-indigo-200 border border-indigo-500/20" : "text-slate-300 hover:bg-slate-800/60 hover:text-white border border-transparent"}`
      }>
      <Icon className="w-4 h-4 shrink-0" strokeWidth={1.5} />
      <span className="truncate">{label}</span>
    </NavLink>
  );
}
