import { useEffect, useMemo, useRef, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Bot, User as UserIcon, Send, Loader2, Sparkles, Target, Trophy, CalendarClock } from "lucide-react";
import { card, chip, lbl, select, btnPrimary, btnGhost, inp } from "@/components/hr/ui";

const SEED = {
  role: "coach",
  content: "Hi — I'm your career coach. I'll ask a few short questions to understand where you want to go over the next 90 days. What's the role, skill, or outcome you'd most like to move on this quarter?",
};

export default function CareerCoach() {
  const [employees, setEmployees] = useState([]);
  const [empId, setEmpId] = useState("");
  const [messages, setMessages] = useState([SEED]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [plan, setPlan] = useState(null);
  const [plans, setPlans] = useState([]);
  const scrollRef = useRef(null);

  useEffect(() => { api.get("/employees").then((r) => setEmployees(r.data)); }, []);
  useEffect(() => { if (empId) api.get(`/coach/plans?employee_id=${empId}`).then((r) => setPlans(r.data)); else setPlans([]); }, [empId]);
  useEffect(() => { scrollRef.current?.scrollTo({ top: 1e9, behavior: "smooth" }); }, [messages, busy]);

  const send = async (e) => {
    e?.preventDefault();
    if (!empId) return toast.error("Pick an employee first.");
    const text = input.trim();
    if (!text) return;
    const history = messages.map((m) => ({ role: m.role === "coach" ? "assistant" : "user", content: m.content }));
    setMessages([...messages, { role: "user", content: text }]);
    setInput("");
    setBusy(true);
    try {
      const { data } = await api.post("/coach/chat", { employee_id: empId, history, message: text });
      setMessages((cur) => [...cur, { role: "coach", content: data.reply }]);
    } catch (err) { toast.error(formatError(err)); setMessages(messages); }
    finally { setBusy(false); }
  };

  const draft = async () => {
    if (!empId) return toast.error("Pick an employee first.");
    if (messages.length < 3) return toast.error("Chat a bit more so the coach has context.");
    setBusy(true);
    try {
      const history = messages.map((m) => ({ role: m.role === "coach" ? "assistant" : "user", content: m.content }));
      const { data } = await api.post("/coach/plan", { employee_id: empId, history });
      setPlan(data);
      toast.success("90-day plan drafted.");
      const list = await api.get(`/coach/plans?employee_id=${empId}`);
      setPlans(list.data);
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const reset = () => { setMessages([SEED]); setPlan(null); };
  const emp = useMemo(() => employees.find((e) => e.id === empId), [employees, empId]);

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Talent Development</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">AI Career Coach</h1>
        <p className="mt-1 text-sm text-slate-400">A short conversation with the coach, then a personalized 90-day growth plan on the spot.</p>
      </div>

      <div className={`${card} p-4 grid md:grid-cols-[1fr_auto] gap-3 items-end`}>
        <label className="block"><span className={lbl}>Employee</span>
          <select data-testid="cc-emp" className={select} value={empId} onChange={(e) => { setEmpId(e.target.value); reset(); }}>
            <option value="" className="bg-slate-900">Select an employee…</option>
            {employees.map((e) => <option key={e.id} value={e.id} className="bg-slate-900">{e.name} · {e.role || "—"}</option>)}
          </select>
        </label>
        <button data-testid="cc-reset" onClick={reset} className={btnGhost}>New conversation</button>
      </div>

      {employees.length === 0 && (
        <div className="p-6 border border-dashed border-slate-800 rounded-xl text-sm text-slate-400">
          Add employees in <span className="text-indigo-300">Competency Mapping</span> to start coaching sessions.
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-6">
        <div className={`${card} p-0 flex flex-col`} style={{ height: "70vh" }}>
          <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-md bg-cyan-500/10 border border-cyan-500/30 grid place-items-center"><Bot className="w-4 h-4 text-cyan-300" strokeWidth={1.5} /></div>
              <div>
                <p className="text-sm text-slate-100">Coach</p>
                <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500">Powered by Claude Sonnet 5</p>
              </div>
            </div>
            <button data-testid="cc-draft" onClick={draft} disabled={busy || messages.length < 3} className={btnPrimary}>
              {busy && !plan ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />} Draft 90-day plan
            </button>
          </div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div key={i} data-testid={`cc-msg-${i}`} className={`flex gap-2 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
                <div className={`w-7 h-7 rounded-md grid place-items-center shrink-0 ${m.role === "user" ? "bg-indigo-500/20 border border-indigo-500/30" : "bg-cyan-500/10 border border-cyan-500/30"}`}>
                  {m.role === "user" ? <UserIcon className="w-3.5 h-3.5 text-indigo-300" /> : <Bot className="w-3.5 h-3.5 text-cyan-300" />}
                </div>
                <div className={`max-w-[80%] px-3 py-2 rounded-lg text-sm ${m.role === "user" ? "bg-indigo-500/10 border border-indigo-500/20 text-indigo-50" : "bg-slate-800/60 border border-slate-700 text-slate-100"}`}>
                  {m.content}
                </div>
              </div>
            ))}
            {busy && !plan && (
              <div className="flex gap-2">
                <div className="w-7 h-7 rounded-md bg-cyan-500/10 border border-cyan-500/30 grid place-items-center"><Bot className="w-3.5 h-3.5 text-cyan-300" /></div>
                <div className="px-3 py-2 rounded-lg text-sm bg-slate-800/60 border border-slate-700 text-slate-400"><Loader2 className="w-3.5 h-3.5 animate-spin inline mr-1" /> thinking…</div>
              </div>
            )}
          </div>
          <form onSubmit={send} className="p-3 border-t border-slate-800 flex gap-2">
            <input data-testid="cc-input" className={inp + " flex-1"} value={input} onChange={(e) => setInput(e.target.value)} placeholder={emp ? `Ask ${emp.name.split(' ')[0]}'s coach…` : "Type a message…"} disabled={!empId || busy} />
            <button data-testid="cc-send" disabled={busy || !empId || !input.trim()} className={btnPrimary}><Send className="w-4 h-4" /></button>
          </form>
        </div>

        <div className={`${card} p-5 space-y-4 max-h-[70vh] overflow-y-auto`}>
          {!plan ? (
            <div className="text-center py-16">
              <Sparkles className="w-6 h-6 mx-auto text-slate-600" strokeWidth={1.5} />
              <p className="mt-3 text-sm text-slate-500">Your 90-day plan will appear here.</p>
              <p className="mt-1 text-xs text-slate-600">Chat a bit, then click Draft 90-day plan.</p>
              {plans.length > 0 && (
                <div className="mt-6 text-left">
                  <p className={lbl}>Previous plans</p>
                  <div className="space-y-2 mt-2">
                    {plans.slice(0, 5).map((p) => (
                      <button key={p.id} data-testid={`cc-prev-${p.id}`} onClick={() => setPlan(p)} className="w-full text-left p-3 rounded-md border border-slate-800 hover:border-slate-700 bg-slate-950">
                        <p className="text-sm text-slate-100 line-clamp-1">{p.content?.north_star || "Growth plan"}</p>
                        <p className="text-xs text-slate-500 font-mono">{new Date(p.created_at).toLocaleString()}</p>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : <PlanView plan={plan.content} /> }
        </div>
      </div>
    </div>
  );
}

function PlanView({ plan }) {
  if (!plan) return null;
  return (
    <div className="space-y-4">
      <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-amber-400 bg-amber-500/5 border border-amber-500/20 rounded-md px-3 py-2">
        AI-generated content. Review with the employee before making commitments.
      </div>
      <div>
        <p className={lbl}>North Star</p>
        <p className="text-slate-100">{plan.north_star}</p>
      </div>
      <div>
        <p className={lbl}>Focus areas</p>
        <div className="flex flex-wrap gap-1.5">{(plan.focus_areas || []).map((f) => <span key={f} className={`${chip} border-indigo-500/20 text-indigo-200`}>{f}</span>)}</div>
      </div>

      {[
        { key: "weeks_1_4", label: "Weeks 1–4", icon: Target, tone: "text-cyan-300 border-cyan-500/30 bg-cyan-500/5" },
        { key: "weeks_5_8", label: "Weeks 5–8", icon: CalendarClock, tone: "text-indigo-300 border-indigo-500/30 bg-indigo-500/5" },
        { key: "weeks_9_12", label: "Weeks 9–12", icon: Trophy, tone: "text-emerald-300 border-emerald-500/30 bg-emerald-500/5" },
      ].map(({ key, label, icon: Icon, tone }) => {
        const phase = plan[key] || {};
        return (
          <div key={key} className={`rounded-lg border ${tone} p-4`}>
            <div className="flex items-center gap-2"><Icon className="w-4 h-4" strokeWidth={1.5} /><p className="font-display text-lg">{label} · <span className="text-slate-100">{phase.theme}</span></p></div>
            <ul className="mt-3 space-y-2">
              {(phase.activities || []).map((a, i) => (
                <li key={i} className="p-3 rounded-md bg-slate-950/60 border border-slate-800">
                  <p className="text-sm text-slate-100">{a.title}</p>
                  <p className="text-xs text-slate-400 mt-1">{a.why}</p>
                  <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500 mt-1">{a.effort}</p>
                </li>
              ))}
            </ul>
            {phase.milestones?.length > 0 && (
              <div className="mt-3">
                <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500">Milestones</p>
                <ul className="mt-1 list-disc list-inside text-xs text-slate-300 space-y-0.5">{phase.milestones.map((m, i) => <li key={i}>{m}</li>)}</ul>
              </div>
            )}
          </div>
        );
      })}

      <div className="grid md:grid-cols-2 gap-3">
        <div><p className={lbl}>Success metrics</p><ul className="list-disc list-inside text-sm text-slate-300 space-y-0.5">{(plan.success_metrics || []).map((m, i) => <li key={i}>{m}</li>)}</ul></div>
        <div><p className={lbl}>Check-ins</p><ul className="list-disc list-inside text-sm text-slate-300 space-y-0.5">{(plan.check_ins || []).map((m, i) => <li key={i}>{m}</li>)}</ul></div>
      </div>
    </div>
  );
}
