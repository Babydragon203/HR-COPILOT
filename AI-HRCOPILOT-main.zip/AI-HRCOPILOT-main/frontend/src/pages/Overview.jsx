import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "@/lib/api";
import { Briefcase, Users, MessageSquare, FileText, ArrowRight } from "lucide-react";
import { CANDIDATE_STAGES } from "@/lib/data";

const CARDS = [
  { key: "active_jobs", label: "Active Jobs", icon: Briefcase, cta: "Create job", to: "/dashboard/jobs" },
  { key: "candidates", label: "Candidates", icon: Users, cta: "Upload resume", to: "/dashboard/resume-analyzer" },
  { key: "pending_interviews", label: "Pending Interviews", icon: MessageSquare, cta: "Create interview kit", to: "/dashboard/interview-assistant" },
  { key: "job_descriptions", label: "Job Descriptions", icon: FileText, cta: "Generate JD", to: "/dashboard/jd-generator" },
];

export default function Overview() {
  const [d, setD] = useState(null);
  useEffect(() => { api.get("/overview").then((r) => setD(r.data)); }, []);

  const empty = d && d.active_jobs === 0 && d.candidates === 0 && d.job_descriptions === 0;

  return (
    <div className="space-y-8 max-w-7xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Dashboard</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Overview</h1>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {CARDS.map((c) => {
          const val = d?.[c.key];
          return (
            <Link to={c.to} key={c.key} data-testid={`kpi-${c.key}`} className="p-5 bg-slate-900 border border-slate-800 rounded-xl hover:border-slate-700 transition-colors block">
              <div className="flex items-start justify-between">
                <c.icon className="w-5 h-5 text-indigo-300" strokeWidth={1.5} />
                <ArrowRight className="w-4 h-4 text-slate-600" />
              </div>
              <p className="mt-4 text-xs font-mono uppercase tracking-[0.2em] text-slate-500">{c.label}</p>
              <p className="mt-1 font-display text-3xl font-semibold text-slate-100">{val ?? "—"}</p>
              {val === 0 && <p className="mt-1 text-xs text-slate-500">{c.cta} →</p>}
            </Link>
          );
        })}
      </div>

      {empty && (
        <div className="p-8 border border-dashed border-slate-800 rounded-xl bg-slate-900/40">
          <h3 className="font-display text-xl">Your workspace is empty.</h3>
          <p className="mt-1 text-sm text-slate-400">Start by generating a JD, uploading a resume, or seeding demo data from Settings to explore.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Link data-testid="empty-generate-jd" to="/dashboard/jd-generator" className="px-4 py-2 rounded-md bg-indigo-600 hover:bg-indigo-500 text-sm">Generate JD</Link>
            <Link data-testid="empty-upload-resume" to="/dashboard/resume-analyzer" className="px-4 py-2 rounded-md border border-slate-800 hover:border-slate-700 text-sm">Upload resume</Link>
            <Link data-testid="empty-seed-demo" to="/dashboard/settings" className="px-4 py-2 rounded-md border border-slate-800 hover:border-slate-700 text-sm">Seed demo data</Link>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 bg-slate-900 border border-slate-800 rounded-xl">
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Candidate Pipeline</p>
          <div className="mt-4 grid grid-cols-3 sm:grid-cols-5 gap-3">
            {CANDIDATE_STAGES.slice(0, 9).map((s) => (
              <div key={s.key} className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500">{s.label}</p>
                <p className="mt-1 font-display text-2xl font-semibold">{d?.pipeline?.[s.key] ?? 0}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl">
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Recent Activity</p>
          {(!d || d.recent_activity?.length === 0) ? (
            <p className="mt-4 text-sm text-slate-500">No activity yet.</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {d.recent_activity.map((a) => (
                <li key={a.id} className="text-sm">
                  <p className="text-slate-200">{a.action.replace(".", " · ")}</p>
                  <p className="text-xs text-slate-500 font-mono">{new Date(a.created_at).toLocaleString()}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
