import { useEffect, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Plus, Briefcase, X } from "lucide-react";
import {
  DEPARTMENTS, JOB_TITLES, SENIORITIES, EXPERIENCE_RANGES,
  EMPLOYMENT_TYPES, WORK_ARRANGEMENTS, PRIORITIES, TIMELINES,
  CURRENCIES, JOB_STATUSES, ALL_SKILLS,
} from "@/lib/data";
import { inp, lbl, select, chip, card, badge } from "@/components/hr/ui";
import SkillsPicker from "@/components/hr/SkillsPicker";

const emptyForm = {
  title: "", department: "", seniority: "Mid Level", experience: "3-5 years",
  employment_type: "Full-time", work_arrangement: "Hybrid", location: "",
  salary_currency: "USD", salary_min: "", salary_max: "",
  priority: "Medium", timeline: "Within 30 Days",
  required_skills: [], preferred_skills: [], qualifications: [],
  status: "draft",
};

export default function Jobs() {
  const [jobs, setJobs] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const load = async () => { const { data } = await api.get("/jobs"); setJobs(data); };
  useEffect(() => { load(); }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form };
      payload.salary_min = payload.salary_min ? Number(payload.salary_min) : null;
      payload.salary_max = payload.salary_max ? Number(payload.salary_max) : null;
      await api.post("/jobs", payload);
      toast.success("Job created.");
      setForm(emptyForm); setShowForm(false); load();
    } catch (err) { toast.error(formatError(err)); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Recruitment</p>
          <h1 className="mt-2 font-display text-3xl font-semibold">Jobs</h1>
        </div>
        <button data-testid="jobs-new-btn" onClick={() => setShowForm(true)} className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 px-4 py-2 rounded-md text-sm font-medium">
          <Plus className="w-4 h-4" /> New Job
        </button>
      </div>

      {showForm && (
        <form onSubmit={submit} className={`${card} p-6 space-y-4`} data-testid="jobs-form">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg">Create Job</h2>
            <button type="button" onClick={() => setShowForm(false)}><X className="w-4 h-4 text-slate-500" /></button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <Field label="Job title *"><input required data-testid="job-title" className={inp} list="titles" value={form.title} onChange={(e) => set("title", e.target.value)} /><datalist id="titles">{JOB_TITLES.map((t) => <option key={t} value={t} />)}</datalist></Field>
            <Field label="Department *"><select required data-testid="job-department" className={select} value={form.department} onChange={(e) => set("department", e.target.value)}><option value="">Select…</option>{DEPARTMENTS.map((d) => <option key={d} value={d} className="bg-slate-900">{d}</option>)}</select></Field>
            <Field label="Seniority"><select className={select} value={form.seniority} onChange={(e) => set("seniority", e.target.value)}>{SENIORITIES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Experience"><select className={select} value={form.experience} onChange={(e) => set("experience", e.target.value)}>{EXPERIENCE_RANGES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Employment type"><select className={select} value={form.employment_type} onChange={(e) => set("employment_type", e.target.value)}>{EMPLOYMENT_TYPES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Work arrangement"><select className={select} value={form.work_arrangement} onChange={(e) => set("work_arrangement", e.target.value)}>{WORK_ARRANGEMENTS.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Location"><input className={inp} value={form.location} onChange={(e) => set("location", e.target.value)} placeholder="City, Country or Remote" /></Field>
            <Field label="Priority"><select className={select} value={form.priority} onChange={(e) => set("priority", e.target.value)}>{PRIORITIES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Timeline"><select className={select} value={form.timeline} onChange={(e) => set("timeline", e.target.value)}>{TIMELINES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <Field label="Status"><select className={select} value={form.status} onChange={(e) => set("status", e.target.value)}>{JOB_STATUSES.map((s) => <option key={s.key} value={s.key} className="bg-slate-900">{s.label}</option>)}</select></Field>
            <Field label="Currency"><select className={select} value={form.salary_currency} onChange={(e) => set("salary_currency", e.target.value)}>{CURRENCIES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
            <div className="grid grid-cols-2 gap-2">
              <Field label="Salary min"><input type="number" className={inp} value={form.salary_min} onChange={(e) => set("salary_min", e.target.value)} /></Field>
              <Field label="Salary max"><input type="number" className={inp} value={form.salary_max} onChange={(e) => set("salary_max", e.target.value)} /></Field>
            </div>
          </div>
          <Field label="Required skills">
            <SkillsPicker value={form.required_skills} onChange={(v) => set("required_skills", v)} testId="req-skills" />
          </Field>
          <Field label="Preferred skills">
            <SkillsPicker value={form.preferred_skills} onChange={(v) => set("preferred_skills", v)} testId="pref-skills" />
          </Field>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowForm(false)} className="px-4 py-2 rounded-md border border-slate-800 hover:border-slate-700 text-sm">Cancel</button>
            <button data-testid="jobs-submit" disabled={saving} className="px-4 py-2 rounded-md bg-indigo-600 hover:bg-indigo-500 text-sm disabled:opacity-60">{saving ? "Saving…" : "Save Job"}</button>
          </div>
        </form>
      )}

      {jobs.length === 0 && !showForm ? (
        <Empty />
      ) : (
        <div className={`${card} overflow-hidden`}>
          <table className="w-full text-sm">
            <thead className="bg-slate-900 border-b border-slate-800">
              <tr className="text-left text-xs font-mono uppercase tracking-[0.15em] text-slate-500">
                <Th>Title</Th><Th>Department</Th><Th>Seniority</Th><Th>Location</Th><Th>Priority</Th><Th>Status</Th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((j) => (
                <tr key={j.id} data-testid={`job-row-${j.id}`} className="border-b border-slate-800 hover:bg-slate-800/30">
                  <Td><div className="flex items-center gap-2"><Briefcase className="w-4 h-4 text-slate-500" strokeWidth={1.5} /><span className="text-slate-100">{j.title}</span>{j.is_demo && <span className={`${chip} border-cyan-400/20 text-cyan-300`}>DEMO DATA</span>}</div></Td>
                  <Td>{j.department}</Td><Td>{j.seniority}</Td><Td>{j.location || "—"}</Td>
                  <Td><span className={badge(j.priority)}>{j.priority || "—"}</span></Td>
                  <Td><span className={`${chip} border-indigo-500/20 text-indigo-300`}>{j.status}</span></Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

const Th = ({ children }) => <th className="px-4 py-3 font-semibold">{children}</th>;
const Td = ({ children }) => <td className="px-4 py-3 text-slate-300">{children}</td>;
const Field = ({ label, children }) => (<label className="block"><span className={lbl}>{label}</span>{children}</label>);

function Empty() {
  return (
    <div className="p-8 border border-dashed border-slate-800 rounded-xl">
      <h3 className="font-display text-xl">No jobs yet</h3>
      <p className="mt-1 text-sm text-slate-400">Create your first requisition to start hiring.</p>
    </div>
  );
}
