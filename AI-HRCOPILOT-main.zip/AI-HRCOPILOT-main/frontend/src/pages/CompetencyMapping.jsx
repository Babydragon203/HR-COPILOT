import { useEffect, useMemo, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Plus, Target, Trash2, Users, ChevronDown, X, Copy, Upload } from "lucide-react";
import { DEPARTMENTS, JOB_TITLES } from "@/lib/data";
import { inp, select, lbl, card, btnPrimary, btnGhost, chip } from "@/components/hr/ui";

const LEVELS = ["Beginner", "Developing", "Proficient", "Advanced", "Expert"];

export default function CompetencyMapping() {
  const [tab, setTab] = useState("frameworks");
  const [comps, setComps] = useState([]);
  const [frameworks, setFrameworks] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [mappings, setMappings] = useState([]);
  const [showFwForm, setShowFwForm] = useState(false);
  const [showEmpForm, setShowEmpForm] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const [c, f, e, m] = await Promise.all([
      api.get("/competencies"), api.get("/frameworks"),
      api.get("/employees"), api.get("/employee-mappings"),
    ]);
    setComps(c.data); setFrameworks(f.data); setEmployees(e.data); setMappings(m.data);
  };
  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Talent Development</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Competency Mapping</h1>
        <p className="mt-1 text-sm text-slate-400">Define role frameworks with weighted competencies, then map current vs target proficiency for each employee.</p>
      </div>

      <div className="flex gap-1 border-b border-slate-800">
        {[
          { k: "frameworks", label: "Frameworks" },
          { k: "employees", label: "Employees" },
          { k: "mapping", label: "Map Employee" },
        ].map((t) => (
          <button key={t.k} data-testid={`cm-tab-${t.k}`} onClick={() => setTab(t.k)}
            className={`px-4 py-2 text-sm border-b-2 -mb-px ${tab === t.k ? "border-indigo-500 text-indigo-200" : "border-transparent text-slate-400 hover:text-slate-200"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "frameworks" && (
        <FrameworksTab frameworks={frameworks} comps={comps} showForm={showFwForm} setShowForm={setShowFwForm} onSaved={load} busy={busy} setBusy={setBusy} />
      )}
      {tab === "employees" && (
        <EmployeesTab employees={employees} showForm={showEmpForm} setShowForm={setShowEmpForm} onSaved={load} busy={busy} setBusy={setBusy} />
      )}
      {tab === "mapping" && (
        <MappingTab employees={employees} frameworks={frameworks} mappings={mappings} onSaved={load} busy={busy} setBusy={setBusy} />
      )}
    </div>
  );
}

// ---------------- Frameworks ----------------
function FrameworksTab({ frameworks, comps, showForm, setShowForm, onSaved, busy, setBusy }) {
  const [form, setForm] = useState({ name: "", department: "", role: "", description: "", competencies: [] });
  const [q, setQ] = useState("");

  const totalWeight = useMemo(() => form.competencies.reduce((a, c) => a + Number(c.weight || 0), 0), [form.competencies]);

  const addComp = (c) => {
    if (form.competencies.find((x) => x.name === c.name)) return;
    setForm({ ...form, competencies: [...form.competencies, { name: c.name, category: c.category, required_level: 3, weight: 0 }] });
  };
  const updComp = (i, k, v) => setForm({ ...form, competencies: form.competencies.map((c, idx) => idx === i ? { ...c, [k]: v } : c) });
  const rmComp = (i) => setForm({ ...form, competencies: form.competencies.filter((_, idx) => idx !== i) });
  const autoBalance = () => {
    if (form.competencies.length === 0) return;
    const each = Math.floor(100 / form.competencies.length);
    const rem = 100 - each * form.competencies.length;
    setForm({ ...form, competencies: form.competencies.map((c, i) => ({ ...c, weight: i === 0 ? each + rem : each })) });
  };

  const submit = async (e) => {
    e.preventDefault();
    if (form.competencies.length === 0) return toast.error("Add at least one competency.");
    if (totalWeight !== 100) return toast.error(`Weights must sum to 100 (got ${totalWeight}).`);
    setBusy(true);
    try {
      await api.post("/frameworks", {
        ...form,
        competencies: form.competencies.map((c) => ({ ...c, required_level: Number(c.required_level), weight: Number(c.weight) })),
      });
      toast.success("Framework created.");
      setForm({ name: "", department: "", role: "", description: "", competencies: [] });
      setShowForm(false); onSaved();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const del = async (id) => {
    if (!confirm("Delete framework?")) return;
    try { await api.delete(`/frameworks/${id}`); toast.success("Deleted."); onSaved(); }
    catch (err) { toast.error(formatError(err)); }
  };

  const clone = async (id) => {
    const name = prompt("Name for the cloned framework?", "");
    if (name === null) return;
    const bump = prompt("Bump required level by (e.g. 1 for next seniority, 0 for none, -1 for junior)?", "1");
    if (bump === null) return;
    try {
      await api.post(`/frameworks/${id}/clone`, { name: name || null, bump_required_level: Number(bump) || 0 });
      toast.success("Framework cloned.");
      onSaved();
    } catch (err) { toast.error(formatError(err)); }
  };

  const filtered = comps.filter((c) => !q || c.name.toLowerCase().includes(q.toLowerCase()) || (c.category || "").toLowerCase().includes(q.toLowerCase()));

  return (
    <>
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400">{frameworks.length} framework{frameworks.length === 1 ? "" : "s"}</p>
        <button data-testid="fw-new-btn" onClick={() => setShowForm(!showForm)} className={btnPrimary}><Plus className="w-4 h-4" /> New Framework</button>
      </div>

      {showForm && (
        <form onSubmit={submit} className={`${card} p-6 space-y-4`}>
          <div className="grid md:grid-cols-2 gap-3">
            <Field label="Name *"><input required data-testid="fw-name" className={inp} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Senior Product Manager v2026" /></Field>
            <Field label="Role"><input list="cm-titles" className={inp} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} /><datalist id="cm-titles">{JOB_TITLES.map((t) => <option key={t} value={t} />)}</datalist></Field>
            <Field label="Department"><select className={select} value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })}><option value="" className="bg-slate-900">Select…</option>{DEPARTMENTS.map((d) => <option key={d} className="bg-slate-900">{d}</option>)}</select></Field>
            <Field label="Description"><input className={inp} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <p className={lbl + " mb-0"}>Add competencies</p>
              <input data-testid="fw-comp-search" className={`${inp} h-8 w-64`} placeholder="Search competencies…" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <div className="max-h-40 overflow-y-auto rounded-md border border-slate-800 bg-slate-950">
              {filtered.slice(0, 60).map((c) => (
                <button type="button" key={c.id || c.name} onClick={() => addComp(c)} className="w-full text-left px-3 py-1.5 text-sm hover:bg-slate-800/60 text-slate-300 flex items-center justify-between">
                  <span>{c.name}</span>
                  <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">{c.category}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <p className={lbl + " mb-0"}>Selected · required level + weight</p>
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono">Total weight: <span className={totalWeight === 100 ? "text-emerald-300" : "text-rose-300"}>{totalWeight}</span>/100</span>
                <button type="button" onClick={autoBalance} data-testid="fw-autobalance" className={btnGhost + " h-8 text-xs"}>Auto-balance</button>
              </div>
            </div>
            {form.competencies.length === 0 ? (
              <p className="text-xs text-slate-500 p-3 border border-dashed border-slate-800 rounded-md">No competencies selected yet.</p>
            ) : (
              <div className="space-y-2">
                {form.competencies.map((c, i) => (
                  <div key={c.name} className="grid grid-cols-12 gap-2 items-center p-3 rounded-md border border-slate-800 bg-slate-950">
                    <div className="col-span-5">
                      <p className="text-sm text-slate-100">{c.name}</p>
                      <p className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">{c.category || "—"}</p>
                    </div>
                    <div className="col-span-4">
                      <span className={lbl}>Required level</span>
                      <div className="flex gap-1">
                        {[1, 2, 3, 4, 5].map((v) => (
                          <button type="button" key={v} onClick={() => updComp(i, "required_level", v)}
                            data-testid={`fw-lvl-${i}-${v}`}
                            className={`text-xs w-8 h-8 rounded border ${c.required_level === v ? "bg-indigo-500/20 border-indigo-500/40 text-indigo-200" : "border-slate-800 text-slate-400 hover:border-slate-700"}`}>{v}</button>
                        ))}
                      </div>
                    </div>
                    <div className="col-span-2">
                      <span className={lbl}>Weight</span>
                      <input type="number" min="0" max="100" data-testid={`fw-w-${i}`} className={inp + " h-8"} value={c.weight} onChange={(e) => updComp(i, "weight", e.target.value)} />
                    </div>
                    <button type="button" onClick={() => rmComp(i)} className="col-span-1 text-slate-500 hover:text-rose-300 justify-self-end"><X className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2">
            <button type="button" onClick={() => setShowForm(false)} className={btnGhost}>Cancel</button>
            <button data-testid="fw-submit" disabled={busy} className={btnPrimary}>Save framework</button>
          </div>
        </form>
      )}

      {frameworks.length === 0 ? (
        <div className="p-8 border border-dashed border-slate-800 rounded-xl">
          <h3 className="font-display text-xl">No competency frameworks yet</h3>
          <p className="mt-1 text-sm text-slate-400">Create a framework to define what "good" looks like for a role.</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {frameworks.map((f) => (
            <div key={f.id} data-testid={`fw-card-${f.id}`} className={`${card} p-5`}>
              <div className="flex items-start justify-between">
                <div>
                  <Target className="w-4 h-4 text-indigo-300 mb-2" strokeWidth={1.5} />
                  <p className="font-display text-lg">{f.name}</p>
                  <p className="text-xs text-slate-500">{f.role || "—"} · {f.department || "—"}</p>
                </div>
                <button onClick={() => del(f.id)} data-testid={`fw-del-${f.id}`} className="text-slate-500 hover:text-rose-300"><Trash2 className="w-4 h-4" /></button>
              </div>
              <div className="mt-2 flex justify-start">
                <button onClick={() => clone(f.id)} data-testid={`fw-clone-${f.id}`} className="inline-flex items-center gap-1 text-xs text-cyan-300 hover:text-cyan-200"><Copy className="w-3 h-3" /> Clone for next level</button>
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {f.competencies.slice(0, 6).map((c) => (
                  <span key={c.name} className={`${chip} bg-slate-800/40 border-slate-700 text-slate-300`}>
                    {c.name} · L{c.required_level} · {c.weight}%
                  </span>
                ))}
                {f.competencies.length > 6 && <span className="text-xs text-slate-500">+{f.competencies.length - 6} more</span>}
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

// ---------------- Employees ----------------
function EmployeesTab({ employees, showForm, setShowForm, onSaved, busy, setBusy }) {
  const [form, setForm] = useState({ name: "", email: "", role: "", department: "" });
  const [showBulk, setShowBulk] = useState(false);
  const [bulk, setBulk] = useState("name,email,role,department\n");
  const [preview, setPreview] = useState([]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try { await api.post("/employees", form); toast.success("Employee added."); setForm({ name: "", email: "", role: "", department: "" }); setShowForm(false); onSaved(); }
    catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const parseCSV = (text) => {
    const lines = text.trim().split(/\r?\n/).filter(Boolean);
    if (lines.length < 2) return [];
    const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
    const idx = { name: header.indexOf("name"), email: header.indexOf("email"),
                  role: header.indexOf("role"), department: header.indexOf("department") };
    if (idx.name === -1) return [];
    return lines.slice(1).map((line) => {
      const cells = line.split(",").map((c) => c.trim());
      return {
        name: cells[idx.name] || "",
        email: idx.email >= 0 ? cells[idx.email] || null : null,
        role: idx.role >= 0 ? cells[idx.role] || null : null,
        department: idx.department >= 0 ? cells[idx.department] || null : null,
      };
    }).filter((r) => r.name);
  };

  const doPreview = () => {
    const rows = parseCSV(bulk);
    if (rows.length === 0) return toast.error("CSV must have a 'name' column and at least one row.");
    setPreview(rows);
  };

  const doImport = async () => {
    if (preview.length === 0) return;
    setBusy(true);
    try {
      const { data } = await api.post("/employees/bulk", { employees: preview });
      toast.success(`Imported ${data.created} employees.`);
      setBulk("name,email,role,department\n"); setPreview([]); setShowBulk(false); onSaved();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const del = async (id) => {
    if (!confirm("Remove employee?")) return;
    try { await api.delete(`/employees/${id}`); toast.success("Removed."); onSaved(); }
    catch (err) { toast.error(formatError(err)); }
  };

  return (
    <>
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400">{employees.length} employee{employees.length === 1 ? "" : "s"}</p>
        <div className="flex gap-2">
          <button data-testid="emp-bulk-btn" onClick={() => setShowBulk(!showBulk)} className={btnGhost}><Upload className="w-4 h-4" /> Bulk Import</button>
          <button data-testid="emp-new-btn" onClick={() => setShowForm(!showForm)} className={btnPrimary}><Plus className="w-4 h-4" /> Add Employee</button>
        </div>
      </div>

      {showBulk && (
        <div className={`${card} p-4 space-y-3`}>
          <div>
            <p className={lbl}>Paste CSV (header + rows)</p>
            <textarea data-testid="emp-bulk-textarea" rows={8} className={inp + " h-auto py-2 resize-y font-mono text-xs"} value={bulk} onChange={(e) => { setBulk(e.target.value); setPreview([]); }}
              placeholder={"name,email,role,department\nAda Lovelace,ada@example.com,Senior Backend Engineer,Software Engineering\nAlan Turing,alan@example.com,Machine Learning Engineer,Data Science"} />
            <p className="mt-1 text-[11px] text-slate-500">Required column: <span className="font-mono text-slate-300">name</span>. Optional: email, role, department.</p>
          </div>
          <div className="flex gap-2">
            <button data-testid="emp-bulk-preview" onClick={doPreview} className={btnGhost}>Preview</button>
            <button data-testid="emp-bulk-import" onClick={doImport} disabled={preview.length === 0 || busy} className={btnPrimary}>Import {preview.length > 0 ? `${preview.length} employees` : ""}</button>
          </div>
          {preview.length > 0 && (
            <div className="max-h-56 overflow-y-auto rounded-md border border-slate-800 bg-slate-950 text-xs">
              <table className="w-full">
                <thead className="bg-slate-900 text-slate-500"><tr>
                  <th className="text-left px-3 py-2">Name</th><th className="text-left px-3 py-2">Email</th><th className="text-left px-3 py-2">Role</th><th className="text-left px-3 py-2">Department</th>
                </tr></thead>
                <tbody>
                  {preview.map((r, i) => (
                    <tr key={i} className="border-t border-slate-800">
                      <td className="px-3 py-1.5 text-slate-100">{r.name}</td>
                      <td className="px-3 py-1.5 text-slate-400">{r.email || "—"}</td>
                      <td className="px-3 py-1.5 text-slate-400">{r.role || "—"}</td>
                      <td className="px-3 py-1.5 text-slate-400">{r.department || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {showForm && (
        <form onSubmit={submit} className={`${card} p-4 grid md:grid-cols-4 gap-3`}>
          <Field label="Name *"><input required data-testid="emp-name" className={inp} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Email"><input type="email" data-testid="emp-email" className={inp} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          <Field label="Role"><input list="emp-titles" className={inp} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} /><datalist id="emp-titles">{JOB_TITLES.map((t) => <option key={t} value={t} />)}</datalist></Field>
          <Field label="Department"><select className={select} value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })}><option value="" className="bg-slate-900">Select…</option>{DEPARTMENTS.map((d) => <option key={d} className="bg-slate-900">{d}</option>)}</select></Field>
          <div className="md:col-span-4 flex justify-end"><button data-testid="emp-submit" disabled={busy} className={btnPrimary}>Add employee</button></div>
        </form>
      )}

      {employees.length === 0 ? (
        <div className="p-8 border border-dashed border-slate-800 rounded-xl">
          <h3 className="font-display text-xl">No employees yet</h3>
          <p className="mt-1 text-sm text-slate-400">Add employees to map competencies and analyze skill gaps.</p>
        </div>
      ) : (
        <div className={`${card} overflow-hidden`}>
          <table className="w-full text-sm">
            <thead className="bg-slate-900 border-b border-slate-800">
              <tr className="text-left text-xs font-mono uppercase tracking-[0.15em] text-slate-500">
                <th className="px-4 py-3">Name</th><th className="px-4 py-3">Role</th><th className="px-4 py-3">Department</th><th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {employees.map((e) => (
                <tr key={e.id} className="border-b border-slate-800 hover:bg-slate-800/30">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2"><Users className="w-4 h-4 text-slate-500" strokeWidth={1.5} /><span className="text-slate-100">{e.name}</span>{e.is_demo && <span className={`${chip} border-cyan-400/20 text-cyan-300`}>DEMO DATA</span>}</div>
                    <p className="text-xs text-slate-500">{e.email || "—"}</p>
                  </td>
                  <td className="px-4 py-3 text-slate-300">{e.role || "—"}</td>
                  <td className="px-4 py-3 text-slate-300">{e.department || "—"}</td>
                  <td className="px-4 py-3 text-right"><button onClick={() => del(e.id)} data-testid={`emp-del-${e.id}`} className="text-slate-500 hover:text-rose-300"><Trash2 className="w-4 h-4" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}

// ---------------- Mapping (current vs target) ----------------
function MappingTab({ employees, frameworks, mappings, onSaved, busy, setBusy }) {
  const [empId, setEmpId] = useState("");
  const [fwId, setFwId] = useState("");
  const [rows, setRows] = useState([]);

  const fw = frameworks.find((f) => f.id === fwId);
  const existing = mappings.find((m) => m.employee_id === empId && m.framework_id === fwId);

  useEffect(() => {
    if (!fw) { setRows([]); return; }
    const existingMap = Object.fromEntries((existing?.mappings || []).map((m) => [m.competency, m]));
    setRows(fw.competencies.map((c) => {
      const e = existingMap[c.name];
      return {
        competency: c.name, category: c.category, required_level: c.required_level, weight: c.weight,
        current_level: e?.current_level ?? 0,
        target_level: e?.target_level ?? c.required_level,
        notes: e?.notes || "",
      };
    }));
  }, [empId, fwId, frameworks, mappings]);

  const upd = (i, k, v) => setRows(rows.map((r, idx) => idx === i ? { ...r, [k]: v } : r));

  const save = async () => {
    if (!empId || !fwId) return toast.error("Select an employee and framework.");
    setBusy(true);
    try {
      await api.post("/employee-mappings", {
        employee_id: empId, framework_id: fwId,
        mappings: rows.map((r) => ({
          competency: r.competency, current_level: Number(r.current_level),
          target_level: Number(r.target_level), notes: r.notes,
        })),
      });
      toast.success("Mapping saved.");
      onSaved();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-4">
      <div className={`${card} p-4 grid md:grid-cols-2 gap-3`}>
        <Field label="Employee"><select data-testid="mp-emp" className={select} value={empId} onChange={(e) => setEmpId(e.target.value)}><option value="" className="bg-slate-900">Select employee…</option>{employees.map((e) => <option key={e.id} value={e.id} className="bg-slate-900">{e.name} · {e.role || "—"}</option>)}</select></Field>
        <Field label="Framework"><select data-testid="mp-fw" className={select} value={fwId} onChange={(e) => setFwId(e.target.value)}><option value="" className="bg-slate-900">Select framework…</option>{frameworks.map((f) => <option key={f.id} value={f.id} className="bg-slate-900">{f.name}</option>)}</select></Field>
      </div>

      {!fw && <div className="p-6 border border-dashed border-slate-800 rounded-xl text-sm text-slate-500">Pick an employee and framework to begin mapping.</div>}

      {fw && rows.length > 0 && (
        <div className={`${card} overflow-hidden`}>
          <table className="w-full text-sm">
            <thead className="bg-slate-900 border-b border-slate-800">
              <tr className="text-left text-xs font-mono uppercase tracking-[0.15em] text-slate-500">
                <th className="px-4 py-3">Competency</th><th className="px-4 py-3">Required</th><th className="px-4 py-3">Current</th><th className="px-4 py-3">Target</th><th className="px-4 py-3">Notes</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.competency} className="border-b border-slate-800">
                  <td className="px-4 py-3">
                    <p className="text-slate-100">{r.competency}</p>
                    <p className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">{r.category || "—"} · weight {r.weight}%</p>
                  </td>
                  <td className="px-4 py-3"><span className={`${chip} border-indigo-500/20 text-indigo-300`}>L{r.required_level} · {LEVELS[r.required_level - 1]}</span></td>
                  <td className="px-4 py-3"><LevelPicker value={r.current_level} onChange={(v) => upd(i, "current_level", v)} allowZero testId={`mp-curr-${i}`} /></td>
                  <td className="px-4 py-3"><LevelPicker value={r.target_level} onChange={(v) => upd(i, "target_level", v)} testId={`mp-tgt-${i}`} /></td>
                  <td className="px-4 py-3"><input className={inp + " h-8"} value={r.notes} onChange={(e) => upd(i, "notes", e.target.value)} placeholder="Optional" /></td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="p-4 flex justify-end"><button data-testid="mp-save" onClick={save} disabled={busy} className={btnPrimary}>Save mapping</button></div>
        </div>
      )}
    </div>
  );
}

function LevelPicker({ value, onChange, allowZero, testId }) {
  const options = allowZero ? [0, 1, 2, 3, 4, 5] : [1, 2, 3, 4, 5];
  return (
    <div className="flex gap-1">
      {options.map((v) => (
        <button type="button" key={v} data-testid={`${testId}-${v}`} onClick={() => onChange(v)}
          className={`w-7 h-7 rounded text-xs border ${value === v ? "bg-indigo-500/20 border-indigo-500/40 text-indigo-200" : "border-slate-800 text-slate-400 hover:border-slate-700"}`}>
          {v === 0 ? "—" : v}
        </button>
      ))}
    </div>
  );
}

const Field = ({ label, children }) => (<label className="block"><span className={lbl}>{label}</span>{children}</label>);
