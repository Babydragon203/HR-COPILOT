import { Fragment, useEffect, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Users, X, GitCompareArrows } from "lucide-react";
import { CANDIDATE_STAGES } from "@/lib/data";
import { card, chip, select, btnPrimary, btnGhost, lbl } from "@/components/hr/ui";

export default function Candidates() {
  const [items, setItems] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [expanded, setExpanded] = useState(null);
  const [selected, setSelected] = useState([]);
  const [comparison, setComparison] = useState(null);
  const [busy, setBusy] = useState(false);
  const [filterJob, setFilterJob] = useState("");

  const load = async () => {
    const [c, j] = await Promise.all([api.get("/candidates"), api.get("/jobs")]);
    setItems(c.data); setJobs(j.data);
  };
  useEffect(() => { load(); }, []);

  const move = async (id, stage) => {
    try { await api.patch(`/candidates/${id}`, { stage }); toast.success("Stage updated."); load(); }
    catch (err) { toast.error(formatError(err)); }
  };

  const toggleSel = (id) => {
    if (selected.includes(id)) setSelected(selected.filter((x) => x !== id));
    else if (selected.length >= 6) toast.error("Compare up to 6 candidates at a time.");
    else setSelected([...selected, id]);
  };

  const compare = async () => {
    if (selected.length < 2) return toast.error("Pick at least 2 candidates to compare.");
    if (selected.length > 6) return toast.error("Compare up to 6 candidates at a time.");
    setBusy(true);
    try {
      const { data } = await api.post("/candidates/compare", { candidate_ids: selected });
      setComparison(data);
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const jobMap = Object.fromEntries(jobs.map((j) => [j.id, j.title]));
  const filtered = filterJob ? items.filter((c) => c.job_id === filterJob) : items;

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Recruitment</p>
          <h1 className="mt-2 font-display text-3xl font-semibold">Candidates</h1>
        </div>
        <div className="flex items-end gap-2">
          <label className="block">
            <span className={lbl}>Filter by job</span>
            <select data-testid="cand-filter-job" className={select + " w-64"} value={filterJob} onChange={(e) => setFilterJob(e.target.value)}>
              <option value="" className="bg-slate-900">All jobs</option>
              {jobs.map((j) => <option key={j.id} value={j.id} className="bg-slate-900">{j.title}</option>)}
            </select>
          </label>
          <button data-testid="cand-compare-btn" onClick={compare} disabled={selected.length < 2 || busy} className={btnPrimary}>
            <GitCompareArrows className="w-4 h-4" /> Compare {selected.length > 0 ? `(${selected.length})` : ""}
          </button>
        </div>
      </div>

      {comparison && (
        <ComparisonPanel data={comparison} jobMap={jobMap} onClose={() => { setComparison(null); setSelected([]); }} />
      )}

      {filtered.length === 0 ? (
        <div className="p-8 border border-dashed border-slate-800 rounded-xl">
          <h3 className="font-display text-xl">No candidates yet</h3>
          <p className="mt-1 text-sm text-slate-400">Upload a resume from the Resume Analyzer to start building your pipeline.</p>
        </div>
      ) : (
        <div className={`${card} overflow-hidden`}>
          <table className="w-full text-sm">
            <thead className="bg-slate-900 border-b border-slate-800">
              <tr className="text-left text-xs font-mono uppercase tracking-[0.15em] text-slate-500">
                <th className="px-4 py-3 w-8"></th>
                <th className="px-4 py-3">Candidate</th>
                <th className="px-4 py-3">Job</th>
                <th className="px-4 py-3">Fit</th>
                <th className="px-4 py-3">Stage</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => (
                <Fragment key={c.id}>
                  <tr data-testid={`candidate-row-${c.id}`} className="border-b border-slate-800 hover:bg-slate-800/30">
                    <td className="px-4 py-3">
                      <input type="checkbox" data-testid={`cand-sel-${c.id}`}
                        checked={selected.includes(c.id)}
                        disabled={!selected.includes(c.id) && selected.length >= 6}
                        onChange={() => toggleSel(c.id)}
                        className="accent-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed" />
                    </td>
                    <td className="px-4 py-3 align-top">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-slate-500" strokeWidth={1.5} />
                        <span className="text-slate-100">{c.name}</span>
                        {c.is_demo && <span className={`${chip} border-cyan-400/20 text-cyan-300`}>DEMO DATA</span>}
                      </div>
                      <p className="text-xs text-slate-500">{c.email || "—"}</p>
                    </td>
                    <td className="px-4 py-3 text-slate-300 align-top">{jobMap[c.job_id] || "—"}</td>
                    <td className="px-4 py-3 align-top">
                      {c.analysis?.overall_score != null
                        ? <span className="font-mono text-indigo-300">{typeof c.analysis.overall_score === "number" ? c.analysis.overall_score.toFixed(1) : c.analysis.overall_score}</span>
                        : <span className="text-slate-500">—</span>}
                    </td>
                    <td className="px-4 py-3 align-top">
                      <select data-testid={`stage-${c.id}`} className={`${select} w-40`} value={c.stage} onChange={(e) => move(c.id, e.target.value)}>
                        {CANDIDATE_STAGES.map((s) => <option key={s.key} value={s.key} className="bg-slate-900">{s.label}</option>)}
                      </select>
                    </td>
                    <td className="px-4 py-3 align-top">
                      {c.analysis && (
                        <button data-testid={`view-analysis-${c.id}`} onClick={() => setExpanded(expanded === c.id ? null : c.id)}
                          className="text-xs text-indigo-300 hover:text-indigo-200">{expanded === c.id ? "Hide" : "View"} analysis</button>
                      )}
                    </td>
                  </tr>
                  {expanded === c.id && c.analysis && (
                    <tr><td colSpan={6} className="px-4 pb-4 bg-slate-950/50">
                      <div className="p-4 rounded-lg bg-slate-900 border border-slate-800 space-y-3">
                        <p className="text-sm text-slate-300">{c.analysis.summary}</p>
                        <div className="grid md:grid-cols-4 gap-3 text-xs">
                          <Stat label="Skills" v={c.analysis.skill_match_pct} />
                          <Stat label="Experience" v={c.analysis.experience_match_pct} />
                          <Stat label="Qualifications" v={c.analysis.qualification_match_pct} />
                          <Stat label="Other" v={c.analysis.other_match_pct} />
                        </div>
                        <div className="grid md:grid-cols-2 gap-4 text-xs">
                          <List title="Matched skills" items={c.analysis.matched_skills} tone="text-emerald-300" />
                          <List title="Missing skills" items={c.analysis.missing_skills} tone="text-rose-300" />
                          <List title="Strengths" items={c.analysis.strengths} tone="text-slate-200" />
                          <List title="Gaps" items={c.analysis.gaps} tone="text-slate-200" />
                        </div>
                        <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-amber-400/80">
                          Internal Job Match Score · heuristic only, not a hiring decision.
                        </p>
                      </div>
                    </td></tr>
                  )}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ComparisonPanel({ data, jobMap, onClose }) {
  const cellStyle = (v) => v === "match" ? "bg-emerald-500/10 text-emerald-300" : v === "gap" ? "bg-rose-500/10 text-rose-300" : "text-slate-600";
  const symbol = (v) => v === "match" ? "✓" : v === "gap" ? "✗" : "·";
  return (
    <div className={`${card} p-6 space-y-4`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-cyan-300">Side-by-side comparison</p>
          <h2 className="font-display text-2xl mt-1">{data.candidates.length} candidates</h2>
        </div>
        <button onClick={onClose} data-testid="cand-compare-close" className="text-slate-500 hover:text-white"><X className="w-4 h-4" /></button>
      </div>

      <div className="grid gap-3" style={{ gridTemplateColumns: `160px repeat(${data.candidates.length}, minmax(180px, 1fr))` }}>
        <div />
        {data.candidates.map((c) => (
          <div key={c.id} className="p-3 rounded-md border border-slate-800 bg-slate-950">
            <p className="text-slate-100 font-medium">{c.name}</p>
            <p className="text-xs text-slate-500">{jobMap[c.job_id] || "—"}</p>
            <p className="mt-2 font-mono text-2xl text-indigo-300">{c.score != null ? Number(c.score).toFixed(1) : "—"}</p>
            <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500">match score</p>
            {c.recommendation && <span className={`${chip} border-indigo-500/20 text-indigo-300 mt-2`}>{c.recommendation}</span>}
          </div>
        ))}

        {["skill_pct", "experience_pct", "qualification_pct", "other_pct"].map((k) => (
          <Fragment key={k}>
            <div className="text-xs font-mono uppercase tracking-[0.15em] text-slate-500 self-center">{k.replace("_pct", "").replace(/^./, (c) => c.toUpperCase())}</div>
            {data.candidates.map((c) => (
              <div key={`${c.id}-${k}`} className="p-2 text-sm text-slate-200 font-mono">{c[k] ?? "—"}%</div>
            ))}
          </Fragment>
        ))}

        <div className="col-span-full my-2 border-t border-slate-800" />

        <div className="text-xs font-mono uppercase tracking-[0.15em] text-slate-500">Summary</div>
        {data.candidates.map((c) => (
          <div key={`${c.id}-sum`} className="text-xs text-slate-300 leading-relaxed">{c.summary || "—"}</div>
        ))}

        <div className="col-span-full my-2 border-t border-slate-800" />

        <div className="text-xs font-mono uppercase tracking-[0.15em] text-slate-500">Skills matrix</div>
        {data.candidates.map((c) => (<div key={`${c.id}-h`} />))}

        {data.skill_matrix.slice(0, 30).map((row) => (
          <Fragment key={row.skill}>
            <div className="text-sm text-slate-300 py-1">{row.skill}</div>
            {data.candidates.map((c) => (
              <div key={`${c.id}-${row.skill}`} className={`py-1 px-2 text-center font-mono text-sm rounded ${cellStyle(row.candidates[c.id])}`}>
                {symbol(row.candidates[c.id])}
              </div>
            ))}
          </Fragment>
        ))}
        {data.skill_matrix.length > 30 && (
          <div className="col-span-full text-xs text-slate-500 py-1">+{data.skill_matrix.length - 30} more skills</div>
        )}
      </div>

      <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-amber-400/80">
        Comparative information for human review. The system does not automatically select the "best" candidate.
      </p>
    </div>
  );
}

const Stat = ({ label, v }) => (
  <div className="p-2 rounded bg-slate-950 border border-slate-800">
    <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500">{label}</p>
    <p className="font-mono text-indigo-300 mt-0.5">{v ?? "—"}%</p>
  </div>
);
const List = ({ title, items, tone }) => (
  <div>
    <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500 mb-1">{title}</p>
    <ul className={`list-disc list-inside space-y-0.5 ${tone}`}>{(items || []).map((i, idx) => <li key={idx}>{i}</li>)}{(!items || items.length === 0) && <li className="text-slate-600 list-none">—</li>}</ul>
  </div>
);
