import { Sparkles } from "lucide-react";

export default function ComingSoon({ title }) {
  return (
    <div className="max-w-3xl mx-auto py-12">
      <div className="border border-dashed border-slate-800 rounded-xl p-10 bg-slate-900/40 text-center">
        <Sparkles className="w-6 h-6 mx-auto text-cyan-300" strokeWidth={1.5} />
        <p className="mt-3 text-[10px] font-mono uppercase tracking-[0.2em] text-cyan-300">Coming Soon</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">{title}</h1>
        <p className="mt-3 text-sm text-slate-400 max-w-lg mx-auto">
          Talent Development modules ship in V2. The architecture is already in place — this feature will unlock next.
        </p>
      </div>
    </div>
  );
}
