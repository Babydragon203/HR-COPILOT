import { useEffect, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { MessageSquare, Sparkles, Loader2, Save } from "lucide-react";
import { INTERVIEW_TYPES, SENIORITIES, RECOMMENDATIONS } from "@/lib/data";
import { inp, select, lbl, card, btnPrimary, btnGhost } from "@/components/hr/ui";
import SkillsPicker from "@/components/hr/SkillsPicker";

const RATINGS = [
  { v: 1, label: "Poor" }, { v: 2, label: "Needs Dev." },
  { v: 3, label: "Meets" }, { v: 4, label: "Strong" }, { v: 5, label: "Exceptional" },
];

export default function InterviewAssistant() {
  const [jobs, setJobs] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [form, setForm] = useState({
    job_id: "", candidate_id: "", interview_type: "Behavioral",
    duration_minutes: 60, seniority: "Mid Level",
    required_skills: [], competencies: [], focus_notes: "",
  });
  const [current, setCurrent] = useState(null);
  const [busy, setBusy] = useState(false);
  const [scorecard, setScorecard] = useState(null);
  const [rec, setRec] = useState("Hire");

  const load = async () => {
    const [j, c, i] = await Promise.all([api.get("/jobs"), api.get("/candidates"), api.get("/interviews")]);
    setJobs(j.data); setCandidates(c.data); setInterviews(i.data);
  };
  useEffect(() => { load(); }, []);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const generate = async () => {
    setBusy(true);
    try {
      const { data } = await api.post("/interviews/generate", form);
      setCurrent(data);
      setScorecard(data.kit?.competencies?.map((c) => ({ competency: c.name, rating: 3, evidence: "", notes: "" })) || []);
      toast.success("Interview kit generated.");
      load();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const openInterview = (iv) => {
    setCurrent(iv);
    setScorecard(iv.scorecard?.competency_scores || iv.kit?.competencies?.map((c) => ({ competency: c.name, rating: 3, evidence: "", notes: "" })) || []);
    setRec(iv.recommendation || "Hire");
  };

  const submit = async () => {
    if (!current) return;
    setBusy(true);
    try {
      await api.post(`/interviews/${current.id}/scorecard`, {
        competency_scores: scorecard, recommendation: rec,
      });
      toast.success("Scorecard saved.");
      load();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Recruitment</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Interview Assistant</h1>
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        <div className={`${card} p-6 lg:col-span-2 space-y-4`}>
          <h2 className="font-display text-lg">New interview kit</h2>
          <Field label="Job"><select data-testid="ia-job" className={select} value={form.job_id} onChange={(e) => set("job_id", e.target.value)}><option value="" className="bg-slate-900">Optional</option>{jobs.map((j) => <option key={j.id} value={j.id} className="bg-slate-900">{j.title}</option>)}</select></Field>
          <Field label="Candidate"><select className={select} value={form.candidate_id} onChange={(e) => set("candidate_id", e.target.value)}><option value="" className="bg-slate-900">Optional</option>{candidates.map((c) => <option key={c.id} value={c.id} className="bg-slate-900">{c.name}</option>)}</select></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Interview type"><select data-testid="ia-type" className={select} value={form.interview_type} onChange={(e) => set("interview_type", e.target.value)}>{INTERVIEW_TYPES.map((t) => <option key={t} className="bg-slate-900">{t}</option>)}</select></Field>
            <Field label="Duration (min)"><input type="number" className={inp} value={form.duration_minutes} onChange={(e) => set("duration_minutes", Number(e.target.value))} /></Field>
            <Field label="Seniority"><select className={select} value={form.seniority} onChange={(e) => set("seniority", e.target.value)}>{SENIORITIES.map((s) => <option key={s} className="bg-slate-900">{s}</option>)}</select></Field>
          </div>
          <Field label="Focus skills"><SkillsPicker value={form.required_skills} onChange={(v) => set("required_skills", v)} testId="ia-skills" /></Field>
          <Field label="Notes"><textarea rows={3} className={`${inp} h-auto py-2 resize-y`} value={form.focus_notes} onChange={(e) => set("focus_notes", e.target.value)} placeholder="Anything to emphasize?" /></Field>
          <button data-testid="ia-generate" onClick={generate} disabled={busy} className={btnPrimary + " w-full justify-center"}>
            {busy && !current ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />} Generate Kit
          </button>

          <div className="pt-4 border-t border-slate-800">
            <p className={lbl}>Recent interviews</p>
            <div className="space-y-1 max-h-60 overflow-y-auto">
              {interviews.length === 0 && <p className="text-xs text-slate-500">No interviews yet.</p>}
              {interviews.map((iv) => (
                <button key={iv.id} data-testid={`ia-open-${iv.id}`} onClick={() => openInterview(iv)} className="w-full text-left px-3 py-2 rounded-md border border-slate-800 hover:border-slate-700 text-sm">
                  <p className="text-slate-200">{iv.interview_type} · {iv.duration_minutes}m</p>
                  <p className="text-xs text-slate-500">{iv.recommendation ? <span className="text-emerald-300">{iv.recommendation}</span> : "Pending scorecard"}</p>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className={`${card} p-6 lg:col-span-3 space-y-4 max-h-[85vh] overflow-y-auto`}>
          {!current && <div className="p-8 border border-dashed border-slate-800 rounded-lg text-center text-slate-500"><MessageSquare className="w-6 h-6 mx-auto text-slate-600" /><p className="mt-2 text-sm">Generate an interview kit to get started.</p></div>}

          {current && (
            <>
              <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-amber-400 bg-amber-500/5 border border-amber-500/20 rounded-md px-3 py-2">
                AI-generated content. Human interviewer remains responsible for the final decision.
              </div>

              {current.kit?.plan && (
                <div className="border border-slate-800 rounded-lg p-4">
                  <p className={lbl}>Plan</p>
                  <p className="text-sm text-slate-300">{current.kit.plan.summary}</p>
                  <div className="mt-2 flex flex-wrap gap-2 text-xs">
                    {(current.kit.plan.sections || []).map((s, i) => (
                      <span key={i} className="px-2 py-0.5 rounded-full border border-slate-800 text-slate-400 font-mono">{s.name} · {s.minutes}m</span>
                    ))}
                  </div>
                </div>
              )}

              <div className="border border-slate-800 rounded-lg p-4 space-y-3">
                <p className={lbl}>Questions</p>
                {(current.kit?.questions || []).map((q, i) => (
                  <div key={q.id || i} className="p-3 rounded-md bg-slate-950 border border-slate-800">
                    <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-indigo-300">{q.category}</p>
                    <p className="text-sm text-slate-100 mt-1">{i + 1}. {q.question}</p>
                    {q.follow_ups?.length > 0 && (
                      <ul className="mt-2 text-xs text-slate-400 list-disc list-inside">{q.follow_ups.map((f, j) => <li key={j}>{f}</li>)}</ul>
                    )}
                    {q.what_good_looks_like && <p className="mt-2 text-xs text-emerald-300/80"><span className="font-mono uppercase tracking-wider">Strong signal:</span> {q.what_good_looks_like}</p>}
                    {q.red_flags?.length > 0 && <p className="mt-1 text-xs text-rose-300/80"><span className="font-mono uppercase tracking-wider">Red flags:</span> {q.red_flags.join(" · ")}</p>}
                  </div>
                ))}
              </div>

              <div className="border border-slate-800 rounded-lg p-4">
                <p className={lbl}>Scorecard</p>
                <div className="space-y-3">
                  {(scorecard || []).map((s, i) => (
                    <div key={i} className="p-3 rounded-md bg-slate-950 border border-slate-800">
                      <p className="text-sm text-slate-100">{s.competency}</p>
                      <div className="flex gap-1 mt-2">
                        {RATINGS.map((r) => (
                          <button key={r.v} data-testid={`sc-${i}-${r.v}`} onClick={() => setScorecard(scorecard.map((x, idx) => idx === i ? { ...x, rating: r.v } : x))}
                            className={`text-[11px] px-2.5 py-1 rounded-full border ${s.rating === r.v ? "bg-indigo-500/10 border-indigo-500/30 text-indigo-200" : "border-slate-800 text-slate-400 hover:border-slate-700"}`}>
                            {r.v} · {r.label}
                          </button>
                        ))}
                      </div>
                      <textarea rows={2} className={`${inp} h-auto py-2 resize-y mt-2 text-sm`} placeholder="Evidence…"
                        value={s.evidence} onChange={(e) => setScorecard(scorecard.map((x, idx) => idx === i ? { ...x, evidence: e.target.value } : x))} />
                    </div>
                  ))}
                </div>

                <div className="mt-4 flex items-center gap-3">
                  <span className={lbl + " mb-0"}>Recommendation</span>
                  <select data-testid="ia-recommendation" className={select + " w-56"} value={rec} onChange={(e) => setRec(e.target.value)}>
                    {RECOMMENDATIONS.map((r) => <option key={r} className="bg-slate-900">{r}</option>)}
                  </select>
                  <button data-testid="ia-save-scorecard" onClick={submit} disabled={busy} className={btnPrimary}><Save className="w-4 h-4" /> Save Scorecard</button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

const Field = ({ label, children }) => (<label className="block"><span className={lbl}>{label}</span>{children}</label>);
