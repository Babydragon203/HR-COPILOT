import { useEffect, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { TrendingUp, ClipboardList, ArrowRight } from "lucide-react";
import { inp, select, lbl, card, btnPrimary, btnGhost, chip } from "@/components/hr/ui";

const LEVEL_LABELS = ["Not assessed", "Beginner", "Developing", "Proficient", "Advanced", "Expert"];
const PRIORITY_STYLES = {
  "Critical": "bg-rose-500/10 border-rose-500/20 text-rose-300",
  "High": "bg-amber-500/10 border-amber-500/20 text-amber-300",
  "Medium": "bg-indigo-500/10 border-indigo-500/20 text-indigo-300",
  "Low": "bg-slate-700/40 border-slate-700 text-slate-300",
  "Met": "bg-emerald-500/10 border-emerald-500/20 text-emerald-300",
  "Not Assessed": "bg-slate-800/40 border-slate-800 text-slate-400",
};

export default function SkillGapAnalyzer() {
  const [employees, setEmployees] = useState([]);
  const [frameworks, setFrameworks] = useState([]);
  const [empId, setEmpId] = useState("");
  const [fwId, setFwId] = useState("");
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [planName, setPlanName] = useState("");
  const [creatingPlan, setCreatingPlan] = useState(false);
  const [plans, setPlans] = useState([]);

  const load = async () => {
    const [e, f, p] = await Promise.all([api.get("/employees"), api.get("/frameworks"), api.get("/development-plans")]);
    setEmployees(e.data); setFrameworks(f.data); setPlans(p.data);
  };
  useEffect(() => { load(); }, []);

  const analyze = async () => {
    if (!empId || !fwId) return toast.error("Select employee and framework.");
    setBusy(true);
    try {
      const { data } = await api.post("/skill-gaps/analyze", { employee_id: empId, framework_id: fwId });
      setResult(data);
      const emp = employees.find((e) => e.id === empId);
      const fw = frameworks.find((f) => f.id === fwId);
      setPlanName(`${emp?.name || "Employee"} — ${fw?.name || "Framework"} plan`);
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const createPlan = async () => {
    if (!result) return;
    const gapItems = result.items.filter((i) => i.assessed && i.gap > 0);
    if (gapItems.length === 0) return toast.error("No gaps to add to a plan.");
    setCreatingPlan(true);
    try {
      await api.post("/development-plans", {
        name: planName || "Development plan",
        employee_id: empId, framework_id: fwId,
        items: gapItems.map((i) => ({
          competency: i.competency, priority: i.priority,
          current_level: i.current_level, target_level: i.required_level,
          activities: [
            `Structured learning on ${i.competency} (course/workshop)`,
            `Apply ${i.competency} in a live cross-functional project`,
            `Peer review or coaching cycle focused on ${i.competency}`,
          ],
        })),
        status: "Not Started",
      });
      toast.success("Development plan created.");
      load();
    } catch (err) { toast.error(formatError(err)); }
    finally { setCreatingPlan(false); }
  };

  const noAssessment = result && result.items.every((i) => !i.assessed);

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Talent Development</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Skill Gap Analyzer</h1>
        <p className="mt-1 text-sm text-slate-400">Spot exactly which skills each employee needs to reach the next level in their role.</p>
      </div>

      <div className={`${card} p-4 grid md:grid-cols-[1fr_1fr_auto] gap-3 items-end`}>
        <Field label="Employee"><select data-testid="sg-emp" className={select} value={empId} onChange={(e) => setEmpId(e.target.value)}><option value="" className="bg-slate-900">Select employee…</option>{employees.map((e) => <option key={e.id} value={e.id} className="bg-slate-900">{e.name} · {e.role || "—"}</option>)}</select></Field>
        <Field label="Framework"><select data-testid="sg-fw" className={select} value={fwId} onChange={(e) => setFwId(e.target.value)}><option value="" className="bg-slate-900">Select framework…</option>{frameworks.map((f) => <option key={f.id} value={f.id} className="bg-slate-900">{f.name}</option>)}</select></Field>
        <button data-testid="sg-analyze" onClick={analyze} disabled={busy || !empId || !fwId} className={btnPrimary}><TrendingUp className="w-4 h-4" /> Analyze</button>
      </div>

      {employees.length === 0 || frameworks.length === 0 ? (
        <div className="p-6 border border-dashed border-slate-800 rounded-xl">
          <p className="text-sm text-slate-400">You need at least one employee and one framework to run an analysis. Head to <span className="text-indigo-300">Competency Mapping</span> to set them up.</p>
        </div>
      ) : null}

      {result && (
        <div className={`${card} p-6 space-y-5`}>
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">{result.employee.name}</p>
              <h2 className="font-display text-2xl">{result.framework.name}</h2>
              <p className="text-sm text-slate-400">{result.framework.role || "—"}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Role readiness</p>
              <p className={`font-display text-4xl ${result.readiness_pct >= 80 ? "text-emerald-300" : result.readiness_pct >= 60 ? "text-amber-300" : "text-rose-300"}`}>{result.readiness_pct}%</p>
              <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500">weighted proficiency</p>
            </div>
          </div>

          {noAssessment && (
            <div className="p-3 rounded-md bg-amber-500/5 border border-amber-500/20 text-xs text-amber-300 font-mono uppercase tracking-[0.15em]">
              Skill level not assessed. Complete the mapping first to get accurate gap priorities.
            </div>
          )}

          <div className="overflow-hidden rounded-lg border border-slate-800">
            <table className="w-full text-sm">
              <thead className="bg-slate-900 border-b border-slate-800">
                <tr className="text-left text-xs font-mono uppercase tracking-[0.15em] text-slate-500">
                  <th className="px-4 py-3">Competency</th><th className="px-4 py-3">Current</th><th className="px-4 py-3">Required</th><th className="px-4 py-3">Gap</th><th className="px-4 py-3">Weight</th><th className="px-4 py-3">Priority</th>
                </tr>
              </thead>
              <tbody>
                {result.items.map((i) => (
                  <tr key={i.competency} data-testid={`sg-row-${i.competency}`} className="border-b border-slate-800">
                    <td className="px-4 py-3">
                      <p className="text-slate-100">{i.competency}</p>
                      <p className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">{i.category || "—"}</p>
                    </td>
                    <td className="px-4 py-3 text-slate-300 font-mono">{i.assessed ? `L${i.current_level} · ${LEVEL_LABELS[i.current_level]}` : "—"}</td>
                    <td className="px-4 py-3 text-slate-300 font-mono">L{i.required_level} · {LEVEL_LABELS[i.required_level]}</td>
                    <td className="px-4 py-3 font-mono text-rose-300">{i.gap > 0 ? `+${i.gap}` : "—"}</td>
                    <td className="px-4 py-3 font-mono text-slate-400">{i.weight}%</td>
                    <td className="px-4 py-3"><span className={`${chip} ${PRIORITY_STYLES[i.priority]}`}>{i.priority}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <div className="flex items-center gap-3 flex-wrap">
              <ClipboardList className="w-4 h-4 text-cyan-300" strokeWidth={1.5} />
              <span className={lbl + " mb-0"}>Convert gaps to development plan</span>
              <input data-testid="sg-plan-name" className={`${inp} flex-1 min-w-[200px]`} value={planName} onChange={(e) => setPlanName(e.target.value)} placeholder="Plan name" />
              <button data-testid="sg-create-plan" onClick={createPlan} disabled={creatingPlan} className={btnPrimary}>Create plan <ArrowRight className="w-4 h-4" /></button>
            </div>
          </div>
        </div>
      )}

      {plans.length > 0 && (
        <div className={`${card} p-6`}>
          <p className={lbl}>Development plans</p>
          <div className="space-y-2">
            {plans.map((p) => {
              const emp = employees.find((e) => e.id === p.employee_id);
              return (
                <div key={p.id} className="p-3 rounded-md border border-slate-800 bg-slate-950">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-100">{p.name}</p>
                      <p className="text-xs text-slate-500">{emp?.name || "—"} · {p.items?.length || 0} items</p>
                    </div>
                    <span className={`${chip} border-indigo-500/20 text-indigo-300`}>{p.status}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

const Field = ({ label, children }) => (<label className="block"><span className={lbl}>{label}</span>{children}</label>);
