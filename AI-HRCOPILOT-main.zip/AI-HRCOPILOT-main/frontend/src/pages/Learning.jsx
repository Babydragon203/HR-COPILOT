import { useEffect, useMemo, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { GraduationCap, Sparkles, Loader2, BookOpen, Users2, Wrench, MessageCircle, Rocket, ClipboardList, PenLine, Video, Check, CircleDot, Circle, ArrowUpCircle } from "lucide-react";
import { card, chip, lbl, select, btnPrimary, btnGhost } from "@/components/hr/ui";

const CATEGORY_ICONS = {
  "Course": BookOpen, "Certification": ClipboardList, "Project": Rocket,
  "Mentoring": Users2, "Coaching": MessageCircle, "Workshop": Video,
  "Reading": PenLine, "On-the-job": Wrench,
};
const PRIORITY_STYLES = {
  "Critical": "bg-rose-500/10 border-rose-500/20 text-rose-300",
  "High": "bg-amber-500/10 border-amber-500/20 text-amber-300",
  "Medium": "bg-indigo-500/10 border-indigo-500/20 text-indigo-300",
  "Low": "bg-slate-700/40 border-slate-700 text-slate-300",
};

export default function Learning() {
  const [employees, setEmployees] = useState([]);
  const [frameworks, setFrameworks] = useState([]);
  const [saved, setSaved] = useState([]);
  const [empId, setEmpId] = useState("");
  const [fwId, setFwId] = useState("");
  const [current, setCurrent] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const [e, f, l] = await Promise.all([api.get("/employees"), api.get("/frameworks"), api.get("/learning")]);
    setEmployees(e.data); setFrameworks(f.data); setSaved(l.data);
  };
  useEffect(() => { load(); }, []);

  const empMap = useMemo(() => Object.fromEntries(employees.map((e) => [e.id, e])), [employees]);
  const fwMap = useMemo(() => Object.fromEntries(frameworks.map((f) => [f.id, f])), [frameworks]);

  const generate = async () => {
    if (!empId || !fwId) return toast.error("Select employee and framework.");
    setBusy(true);
    try {
      const { data } = await api.post("/learning/generate", { employee_id: empId, framework_id: fwId });
      setCurrent(data);
      toast.success("Learning recommendations generated.");
      load();
    } catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  const content = current?.content;

  const cycleStatus = async (recIdx, actIdx, currentStatus) => {
    const next = currentStatus === "done" ? "todo" : currentStatus === "in_progress" ? "done" : "in_progress";
    try {
      const { data } = await api.patch(`/learning/${current.id}/activity`, { rec_index: recIdx, act_index: actIdx, status: next });
      setCurrent(data);
    } catch (err) { toast.error(formatError(err)); }
  };

  const promptLevelUp = async (competency) => {
    const v = prompt(`Confirm new proficiency level for "${competency}" (1-5):`, "4");
    if (!v) return;
    const n = Number(v);
    if (!Number.isInteger(n) || n < 1 || n > 5) return toast.error("Level must be 1-5.");
    try {
      await api.post(`/learning/${current.id}/level-up`, { competency, new_level: n });
      toast.success(`${competency} → Level ${n}. Readiness will reflect in Career Path & Skill Gap.`);
    } catch (err) { toast.error(formatError(err)); }
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Talent Development</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Learning Recommendations</h1>
        <p className="mt-1 text-sm text-slate-400">Turn each assessed skill gap into an action step: courses, projects, mentoring, and more.</p>
      </div>

      <div className={`${card} p-4 grid md:grid-cols-[1fr_1fr_auto] gap-3 items-end`}>
        <label className="block"><span className={lbl}>Employee</span>
          <select data-testid="lr-emp" className={select} value={empId} onChange={(e) => setEmpId(e.target.value)}>
            <option value="" className="bg-slate-900">Select employee…</option>
            {employees.map((e) => <option key={e.id} value={e.id} className="bg-slate-900">{e.name} · {e.role || "—"}</option>)}
          </select>
        </label>
        <label className="block"><span className={lbl}>Framework / Target Role</span>
          <select data-testid="lr-fw" className={select} value={fwId} onChange={(e) => setFwId(e.target.value)}>
            <option value="" className="bg-slate-900">Select framework…</option>
            {frameworks.map((f) => <option key={f.id} value={f.id} className="bg-slate-900">{f.name}</option>)}
          </select>
        </label>
        <button data-testid="lr-generate" onClick={generate} disabled={busy || !empId || !fwId} className={btnPrimary}>
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />} Generate
        </button>
      </div>

      {employees.length === 0 || frameworks.length === 0 ? (
        <div className="p-6 border border-dashed border-slate-800 rounded-xl">
          <p className="text-sm text-slate-400">You need employees + a framework with mapped current levels first. Set them up in <span className="text-indigo-300">Competency Mapping</span>.</p>
        </div>
      ) : null}

      {content && (
        <div className={`${card} p-6 space-y-4`}>
          <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-amber-400 bg-amber-500/5 border border-amber-500/20 rounded-md px-3 py-2">
            AI-generated content. Review before assigning to team members.
          </div>
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Plan overview</p>
              <p className="mt-2 text-sm text-slate-300 leading-relaxed">{content.overview}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">For</p>
              <p className="font-display text-lg text-slate-100">{empMap[current.employee_id]?.name}</p>
              <p className="text-xs text-slate-500">Target: {fwMap[current.framework_id]?.name}</p>
            </div>
          </div>

          <div className="space-y-3">
            {(content.recommendations || []).map((r, i) => {
              const acts = r.activities || [];
              const done = acts.filter((a) => a.status === "done").length;
              const pct = acts.length ? Math.round((done / acts.length) * 100) : 0;
              return (
              <div key={i} data-testid={`lr-rec-${i}`} className="p-4 rounded-lg bg-slate-950 border border-slate-800">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-indigo-300" strokeWidth={1.5} />
                    <p className="text-sm text-slate-100">{r.competency}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-slate-400">{done}/{acts.length} done</span>
                    <span className={`${chip} ${PRIORITY_STYLES[r.priority] || PRIORITY_STYLES.Medium}`}>{r.priority}</span>
                  </div>
                </div>
                <div className="mt-2 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div className="h-full bg-emerald-400" style={{ width: `${pct}%` }} />
                </div>
                <p className="mt-2 text-xs text-slate-400">{r.learning_objective}</p>
                <div className="mt-3 grid md:grid-cols-2 gap-2">
                  {acts.map((a, j) => (
                    <ActivityCard key={j} activity={a} onCycle={() => cycleStatus(i, j, a.status)} testId={`lr-act-${i}-${j}`} />
                  ))}
                </div>
                {pct === 100 && (
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <ArrowUpCircle className="w-4 h-4 text-emerald-300" strokeWidth={1.5} />
                    <span className="text-xs text-emerald-300">All activities complete — confirm the new proficiency level to update readiness.</span>
                    <button data-testid={`lr-levelup-${i}`} onClick={() => promptLevelUp(r.competency)} className={btnGhost + " h-8 text-xs"}>Confirm level up</button>
                  </div>
                )}
              </div>
            );})}
          </div>
        </div>
      )}

      {saved.length > 0 && !current && (
        <div className={`${card} p-6`}>
          <p className={lbl}>Recent learning plans</p>
          <div className="space-y-2 mt-2">
            {saved.slice(0, 8).map((s) => {
              const emp = empMap[s.employee_id];
              const fw = fwMap[s.framework_id];
              return (
                <button key={s.id} data-testid={`lr-open-${s.id}`} onClick={() => setCurrent(s)} className="w-full text-left p-3 rounded-md border border-slate-800 hover:border-slate-700 bg-slate-950">
                  <p className="text-sm text-slate-100">{emp?.name || "—"} → {fw?.name || "—"}</p>
                  <p className="text-xs text-slate-500 font-mono">{new Date(s.created_at).toLocaleString()} · {s.content?.recommendations?.length || 0} recommendations</p>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function ActivityCard({ activity, onCycle, testId }) {
  const Icon = CATEGORY_ICONS[activity.category] || BookOpen;
  const StatusIcon = activity.status === "done" ? Check : activity.status === "in_progress" ? CircleDot : Circle;
  const ringTone = activity.status === "done" ? "border-emerald-500/40 bg-emerald-500/5"
    : activity.status === "in_progress" ? "border-indigo-500/40 bg-indigo-500/5"
    : "border-slate-800 bg-slate-900";
  return (
    <div className={`p-3 rounded-md border ${ringTone}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <Icon className="w-3.5 h-3.5 text-cyan-300" strokeWidth={1.5} />
          <span className="text-[10px] font-mono uppercase tracking-[0.15em] text-cyan-300">{activity.category}</span>
        </div>
        <button data-testid={testId} onClick={onCycle} title={`Status: ${activity.status || "todo"}`}
          className={`text-xs inline-flex items-center gap-1 px-2 py-0.5 rounded-full border ${activity.status === "done" ? "border-emerald-500/40 text-emerald-300" : activity.status === "in_progress" ? "border-indigo-500/40 text-indigo-300" : "border-slate-700 text-slate-400 hover:border-slate-600"}`}>
          <StatusIcon className="w-3 h-3" /> {(activity.status || "todo").replace("_", " ")}
        </button>
      </div>
      <p className="mt-1 text-sm text-slate-100">{activity.title}</p>
      <p className="mt-1 text-xs text-slate-400">{activity.reason}</p>
      <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 font-mono">
        <span>{activity.estimated_effort}</span>
        <span className="text-emerald-300/80">→ {activity.expected_outcome}</span>
      </div>
    </div>
  );
}
