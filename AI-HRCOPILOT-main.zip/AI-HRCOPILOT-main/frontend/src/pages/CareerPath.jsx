import { useEffect, useMemo, useState } from "react";
import api, { formatError } from "@/lib/api";
import { toast } from "sonner";
import { Route, ArrowRight, CheckCircle2, AlertCircle } from "lucide-react";
import { card, chip, lbl, select, btnPrimary } from "@/components/hr/ui";

export default function CareerPath() {
  const [employees, setEmployees] = useState([]);
  const [empId, setEmpId] = useState("");
  const [data, setData] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.get("/employees").then((r) => setEmployees(r.data)); }, []);

  const load = async (id) => {
    setBusy(true);
    try { const { data } = await api.get(`/employees/${id}/career-path`); setData(data); }
    catch (err) { toast.error(formatError(err)); }
    finally { setBusy(false); }
  };

  useEffect(() => { if (empId) load(empId); else setData(null); }, [empId]);

  const currentRole = useMemo(() => data?.paths?.find((p) => p.role_match), [data]);
  const others = useMemo(() => (data?.paths || []).filter((p) => !p.role_match), [data]);

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <p className="text-xs font-mono uppercase tracking-[0.2em] text-slate-500">Talent Development</p>
        <h1 className="mt-2 font-display text-3xl font-semibold">Career Path</h1>
        <p className="mt-1 text-sm text-slate-400">See each employee's readiness across every role framework in the org and their next promotion at a glance.</p>
      </div>

      <div className={`${card} p-4`}>
        <label className="block max-w-md">
          <span className={lbl}>Employee</span>
          <select data-testid="cp-emp" className={select} value={empId} onChange={(e) => setEmpId(e.target.value)}>
            <option value="" className="bg-slate-900">Select an employee…</option>
            {employees.map((e) => <option key={e.id} value={e.id} className="bg-slate-900">{e.name} · {e.role || "—"}</option>)}
          </select>
        </label>
      </div>

      {!empId && employees.length === 0 && (
        <div className="p-6 border border-dashed border-slate-800 rounded-xl">
          <p className="text-sm text-slate-400">Add employees in <span className="text-indigo-300">Competency Mapping</span> to see their career paths.</p>
        </div>
      )}

      {busy && <p className="text-sm text-slate-500">Loading…</p>}

      {data && data.paths.length === 0 && (
        <div className="p-6 border border-dashed border-slate-800 rounded-xl">
          <p className="text-sm text-slate-400">No frameworks exist yet in your org. Create at least one in Competency Mapping.</p>
        </div>
      )}

      {data && data.paths.length > 0 && (
        <>
          {currentRole && <PathCard path={currentRole} tag="Current role" tone="cyan" />}
          {others.length > 0 && (
            <div className="space-y-3">
              <p className={lbl}>Next steps & lateral moves</p>
              <div className="grid md:grid-cols-2 gap-4">
                {others.map((p) => <PathCard key={p.framework_id} path={p} tag={p.readiness_pct >= 80 ? "Promotion ready" : p.readiness_pct >= 60 ? "Development area" : "Stretch"} tone={p.readiness_pct >= 80 ? "emerald" : p.readiness_pct >= 60 ? "amber" : "slate"} />)}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

const TONE = {
  cyan: { bar: "bg-cyan-400", chip: "border-cyan-400/20 text-cyan-300" },
  emerald: { bar: "bg-emerald-400", chip: "border-emerald-400/20 text-emerald-300" },
  amber: { bar: "bg-amber-400", chip: "border-amber-400/20 text-amber-300" },
  slate: { bar: "bg-slate-500", chip: "border-slate-700 text-slate-400" },
};

function PathCard({ path, tag, tone }) {
  const t = TONE[tone];
  const pct = Math.max(0, Math.min(100, path.readiness_pct));
  return (
    <div data-testid={`cp-card-${path.framework_id}`} className={`${card} p-5`}>
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <Route className="w-4 h-4 text-indigo-300" strokeWidth={1.5} />
            <p className="font-display text-lg">{path.framework_name}</p>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">{path.role || "—"} · {path.department || "—"}</p>
        </div>
        <span className={`${chip} ${t.chip}`}>{tag}</span>
      </div>

      <div className="mt-4">
        <div className="flex items-baseline justify-between">
          <p className="text-xs font-mono uppercase tracking-[0.15em] text-slate-500">Readiness</p>
          <p className="font-mono text-lg text-slate-100">{pct}%</p>
        </div>
        <div className="mt-1 h-2 rounded-full bg-slate-800 overflow-hidden">
          <div className={`h-full ${t.bar}`} style={{ width: `${pct}%` }} />
        </div>
        <p className="mt-1 text-[10px] font-mono uppercase tracking-[0.15em] text-slate-500">
          {path.has_mapping ? `${path.assessed_count}/${path.total_competencies} competencies assessed` : "Not yet mapped"}
        </p>
      </div>

      {path.top_gaps.length > 0 ? (
        <div className="mt-4">
          <p className="text-xs font-mono uppercase tracking-[0.15em] text-slate-500 flex items-center gap-1"><AlertCircle className="w-3 h-3" /> Focus areas</p>
          <ul className="mt-2 space-y-1 text-sm">
            {path.top_gaps.map((g) => (
              <li key={g.competency} className="flex items-center justify-between text-slate-300">
                <span className="flex items-center gap-1"><ArrowRight className="w-3 h-3 text-slate-500" /> {g.competency}</span>
                <span className="text-xs font-mono text-rose-300">+{g.gap} · {g.weight}%</span>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        path.has_mapping && (
          <p className="mt-4 text-xs text-emerald-300 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> All competencies at or above required level.</p>
        )
      )}
    </div>
  );
}
